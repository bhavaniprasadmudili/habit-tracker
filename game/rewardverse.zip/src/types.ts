export interface UserProfile {
  username: string;
  email: string;
  avatar: string;
  level: number;
  xp: number;
  xpToNextLevel: number;
  coins: number;
  walletBalance: number; // in USD cash
  streakCount: number;
  streakCalendar: { [key: string]: boolean }; // e.g. "2026-05-23": true
  badges: Badge[];
  rank: number;
  securityScore: number; // For fraud prevention: 0-100
  isVerified: boolean;
  deviceCheckOk: boolean;
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  unlockedAt?: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  rewardType: "coins" | "xp" | "wallet" | "spin";
  rewardValue: number;
  progress: number; // e.g., 0 to 100
  maxProgress: number; // e.g., 1 to 5
  isCompleted: boolean;
  isClaimed: boolean;
  category: "daily" | "social" | "challenge";
  iconName: string;
}

export interface SpinReward {
  id: number;
  label: string;
  value: number;
  type: "coins" | "xp" | "spin" | "wallet" | "mystery";
  color: string;
}

export interface SpinHistory {
  id: string;
  timestamp: string;
  rewardLabel: string;
  type: string;
  value: number;
}

export interface WalletTransaction {
  id: string;
  type: "earn" | "withdraw_request" | "withdraw_payout" | "bonus";
  amount: number;
  currency: "coins" | "cash";
  description: string;
  timestamp: string;
  status: "completed" | "pending" | "failed";
}

export interface LeaderboardUser {
  rank: number;
  username: string;
  avatar: string;
  xp: number;
  level: number;
  coins: number;
  isCurrentUser?: boolean;
}

export interface AppNotification {
  id: string;
  title: string;
  description: string;
  timestamp: string;
  read: boolean;
  type: "reward" | "streak" | "bonus" | "achievement" | "security";
  actionLabel?: string;
}

export interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswerIndex: number;
  coinsReward: number;
  xpReward: number;
}
