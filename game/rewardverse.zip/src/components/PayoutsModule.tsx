import React, { useState } from "react";
import { UserProfile, WalletTransaction } from "../types";
import { CreditCard, ShieldAlert, Award, ArrowUpRight, DollarSign, Wallet, CheckCircle, Info, Landmark } from "lucide-react";

interface PayoutsModuleProps {
  user: UserProfile;
  onUpdateUser: (newUser: UserProfile) => void;
  onAddTransaction: (tx: WalletTransaction) => void;
  onTriggerToast: (msg: string, type: "success" | "info" | "error") => void;
  onNavigateToAuth: () => void;
}

type PayoutChannel = "paypal" | "crypto" | "mobile_money" | "gift_card";

export default function PayoutsModule({
  user,
  onUpdateUser,
  onAddTransaction,
  onTriggerToast,
  onNavigateToAuth
}: PayoutsModuleProps) {
  const [selectedChannel, setSelectedChannel] = useState<PayoutChannel>("paypal");
  const [payoutAddress, setPayoutAddress] = useState<string>("");
  const [withdrawAmount, setWithdrawAmount] = useState<number>(10);
  const [payoutSuccess, setPayoutSuccess] = useState<boolean>(false);

  // Dynamic minimums
  const minLimits = { paypal: 5, crypto: 20, mobile_money: 1, gift_card: 10 };

  const handleWithdraw = (e: React.FormEvent) => {
    e.preventDefault();

    // Check balance
    if (user.walletBalance < withdrawAmount) {
      onTriggerToast("Insufficient cash balance for this cashout!", "error");
      return;
    }

    // Check minimum limit
    if (withdrawAmount < minLimits[selectedChannel]) {
      onTriggerToast(`Minimum withdrawal is $${minLimits[selectedChannel]} for this method.`, "error");
      return;
    }

    if (!payoutAddress.trim()) {
      onTriggerToast("Please specify your payout destination address/number.", "error");
      return;
    }

    // Check fraud score
    if (!user.isVerified || user.securityScore < 60) {
      onTriggerToast("Withdrawal rejected: Account integrity check failed! View Anti-Cheat logs.", "error");
      return;
    }

    // Deduct
    const remainingBalance = user.walletBalance - withdrawAmount;
    onUpdateUser({
      ...user,
      walletBalance: remainingBalance
    });

    const newTx: WalletTransaction = {
      id: `PAY-${Math.floor(200000 + Math.random() * 800000)}`,
      type: "withdraw_request",
      amount: withdrawAmount,
      currency: "cash",
      description: `Withdrawal via ${selectedChannel.toUpperCase()} (${payoutAddress.substring(0, 15)}...)`,
      timestamp: new Date().toISOString().replace("T", " ").substring(0, 19),
      status: "pending"
    };

    onAddTransaction(newTx);
    setPayoutSuccess(true);
    onTriggerToast("Withdrawal request dispatched to Django Finance pipeline!", "success");
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 select-none pb-20">
      {/* Route Header Badge */}
      <div className="lg:col-span-12 glass-panel p-4 flex justify-between items-center border border-neon-blue/20">
        <div className="flex items-center space-x-3">
          <CreditCard className="text-neon-cyan w-5 h-5 animate-pulse" />
          <div>
            <span className="text-xs font-mono text-neon-cyan block">DJANGO PLATFORM ROUTE:</span>
            <span className="text-sm font-bold text-white font-mono tracking-wide">/ui/payouts/ [Cashout Terminals]</span>
          </div>
        </div>
        <div className="flex items-center space-x-2 text-xs font-mono">
          <span className="text-gray-400">Merchant Active:</span>
          <span className="text-green-400 font-bold">● ONLINE</span>
        </div>
      </div>

      {/* Fraud Block Panel Warning */}
      {(!user.isVerified || user.securityScore < 60) && (
        <div className="lg:col-span-12 glass-panel p-6 border-2 border-neon-pink/40 bg-gradient-to-r from-red-950/10 via-slate-900/60 to-slate-900/40 relative overflow-hidden flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-start space-x-4">
            <div className="p-3 bg-neon-pink/15 rounded-xl border border-neon-pink/30 text-neon-pink">
              <ShieldAlert className="w-6 h-6 animate-bounce" />
            </div>
            <div>
              <h3 className="font-bold text-base text-white font-mono tracking-wide">
                LOCKDOWN: WITHDRAWAL ACCREDITATION REJECTED
              </h3>
              <p className="text-xs text-gray-300 mt-1 max-w-xl">
                Our Django automated guard system has flagged this session. Minimum profile security score (60) or complete identity validation checks are required to unlock direct monetary cashout ports.
              </p>
              <div className="flex items-center space-x-3 text-[11px] text-neon-pink font-mono mt-2">
                <span>&bull; Integrity Index: {user.securityScore}%</span>
                <span>&bull; Verification: Account Unverified</span>
              </div>
            </div>
          </div>
          <button
            onClick={onNavigateToAuth}
            className="px-5 py-2.5 bg-neon-pink hover:bg-neon-pink/90 text-slate-950 font-bold font-mono text-xs rounded-xl transition-all shadow-lg text-center whitespace-nowrap"
          >
            Authenticate Profile &rarr;
          </button>
        </div>
      )}

      {/* Cashout Checkout Form (Left) */}
      <div className="col-span-1 lg:col-span-8 space-y-6">
        {payoutSuccess ? (
          <div className="glass-panel p-8 border border-green-500/20 bg-green-500/5 text-center flex flex-col items-center">
            <div className="w-16 h-16 rounded-full bg-green-500/15 border border-green-500/30 text-green-400 flex justify-center items-center mb-4">
              <CheckCircle className="w-10 h-10 animate-pulse" />
            </div>
            <h3 className="text-xl font-bold text-white font-mono tracking-tight">CASH COMPONENT DISPATCHED</h3>
            <p className="text-xs text-gray-300 mt-2 max-w-md leading-relaxed">
              Your liquidation request of <span className="text-green-400 font-bold">${withdrawAmount}</span> was submitted to our Django escrow manager for approval.
            </p>

            <div className="bg-black/45 hover:bg-black/60 rounded-xl border border-white/5 p-4 mt-6 w-full max-w-sm text-left font-mono text-xs space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-400">Target Handler:</span>
                <span className="text-white uppercase font-bold">{selectedChannel}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Network Address:</span>
                <span className="text-neon-cyan truncate max-w-[180px]">{payoutAddress}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Escrow SLA:</span>
                <span className="text-[#fbbf24] font-bold">24-48 Hours</span>
              </div>
            </div>

            <div className="flex space-x-3 mt-8">
              <button
                onClick={() => setPayoutSuccess(false)}
                className="px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-xs font-mono text-gray-300"
              >
                Launch Another Request
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleWithdraw} className="glass-panel p-6 border border-white/5 bg-slate-900/40 space-y-6">
            <h3 className="font-bold text-base text-white tracking-tight font-mono flex items-center gap-1.5">
              <Landmark className="w-5 h-5 text-neon-purple" /> CASHOUT METHOD DISPATCH
            </h3>

            {/* Choose Chanel Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { id: "paypal", name: "PayPal Direct", icon: "💎", color: "from-blue-600/20 to-sky-600/20" },
                { id: "crypto", name: "USDT Crypto", icon: "🕸️", color: "from-teal-600/20 to-emerald-600/20" },
                { id: "mobile_money", name: "Mobile Money", icon: "📱", color: "from-orange-600/20 to-yellow-600/20" },
                { id: "gift_card", name: "Gift Card Node", icon: "🎁", color: "from-purple-600/20 to-pink-600/20" }
              ].map((chan) => (
                <div
                  key={chan.id}
                  onClick={() => setSelectedChannel(chan.id as PayoutChannel)}
                  className={`p-3.5 rounded-xl border text-center cursor-pointer transition-all flex flex-col justify-center items-center relative overflow-hidden ${
                    selectedChannel === chan.id
                      ? "border-neon-purple bg-neon-purple/20 shadow-md glow-purple"
                      : "border-white/5 bg-white/5 hover:border-white/15"
                  }`}
                >
                  <span className="text-2xl mb-1">{chan.icon}</span>
                  <span className="text-xs font-bold text-white block truncate">{chan.name}</span>
                  <span className="text-[9px] text-gray-400 font-mono mt-0.5 uppercase">
                    Min ${minLimits[chan.id as PayoutChannel]}
                  </span>
                </div>
              ))}
            </div>

            {/* Inputs */}
            <div className="space-y-4 font-mono text-xs">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-[11px] text-gray-400 block mb-1 uppercase font-bold">
                    Withdrawal cash Value ($)
                  </label>
                  <div className="relative">
                    <span className="absolute left-3.5 top-1/2 transform -translate-y-1/2 text-gray-400 font-bold">
                      $
                    </span>
                    <input
                      type="number"
                      value={withdrawAmount}
                      onChange={(e) => setWithdrawAmount(Math.max(1, parseFloat(e.target.value) || 0))}
                      className="w-full pl-8 pr-3 py-3 bg-black/50 border border-white/10 rounded-lg text-neon-cyan focus:outline-none focus:border-neon-cyan"
                      placeholder="Liquidation amount..."
                    />
                  </div>
                  <span className="text-[9px] text-gray-500 mt-1 block">
                    Available: <span className="text-green-400 font-bold">${user.walletBalance.toFixed(2)}</span>
                  </span>
                </div>

                <div>
                  <label className="text-[11px] text-gray-400 block mb-1 uppercase font-bold">
                    {selectedChannel === "paypal" && "PAYPAL ACCOUNT EMAIL"}
                    {selectedChannel === "crypto" && "BEP-20 / TRC-20 WALLET ADDRESS"}
                    {selectedChannel === "mobile_money" && "PHONE NUMBER (+M-PESA / MTN)"}
                    {selectedChannel === "gift_card" && "RECIPIENT GMAIL FOR CODES ID"}
                  </label>
                  <input
                    type="text"
                    value={payoutAddress}
                    onChange={(e) => setPayoutAddress(e.target.value)}
                    className="w-full p-3 bg-black/50 border border-white/10 rounded-lg text-white focus:outline-none focus:border-neon-purple"
                    placeholder={
                      selectedChannel === "paypal"
                        ? "username@paypal.com"
                        : selectedChannel === "crypto"
                        ? "0x71C...498f"
                        : selectedChannel === "mobile_money"
                        ? "+254 700 000 000"
                        : "gamer@gmail.com"
                    }
                  />
                </div>
              </div>

              <div className="bg-slate-950/80 rounded-xl p-4 border border-white/5 space-y-1 text-gray-400 leading-relaxed text-[11px]">
                <div className="flex justify-between items-center text-white font-bold mb-1">
                  <span className="flex items-center gap-1">
                    <Info className="w-3.5 h-3.5 text-neon-cyan" /> Escrow SLA Processing
                  </span>
                  <span className="text-green-400 bg-green-500/10 px-1.5 py-0.5 rounded text-[10px]">Active</span>
                </div>
                <p>&bull; Transactions are processed via django-celery background pipelines instantly.</p>
                <p>&bull; Gas fees or processing taxes (0.00%) are fully subsidized by RewardVerse.</p>
              </div>

              <button
                type="submit"
                disabled={!user.isVerified || user.securityScore < 60}
                className={`w-full py-3.5 rounded-xl font-bold uppercase tracking-wider text-xs transition-all ${
                  !user.isVerified || user.securityScore < 60
                    ? "bg-slate-900 text-gray-500 border border-white/5 cursor-not-allowed"
                    : "bg-gradient-to-r from-[#ab52f3] to-[#fbbf24] hover:opacity-95 text-slate-950 shadow-md animate-pulse"
                }`}
              >
                {!user.isVerified || user.securityScore < 60
                  ? "ACCRA SYSTEM BLOCKED (VERIFICATION REQD)"
                  : "PROCEED WITH DISPATCH EXPLICIT"}
              </button>
            </div>
          </form>
        )}
      </div>

      {/* SLA Tiers Limits (Right) */}
      <div className="col-span-1 lg:col-span-4 space-y-6">
        <div className="glass-panel p-6 border border-white/5 bg-slate-900/40">
          <h3 className="font-bold text-sm uppercase text-gray-300 tracking-wider mb-4 font-mono flex items-center gap-1.5">
            <ArrowUpRight className="w-4 h-4 text-neon-cyan" /> PAYOUT CAP RULES
          </h3>

          <div className="space-y-3 font-mono text-xs">
            {[
              { level: "Bronze (Lvl 1-4)", limit: "$50 / day", fee: "Free" },
              { level: "Silver (Lvl 5-9)", limit: "$200 / day", fee: "Free" },
              { level: "Gold Pro (Lvl 10+)", limit: "$1,000 / day", fee: "Free + Priority" }
            ].map((v, i) => (
              <div
                key={i}
                className="p-3 bg-black/45 rounded-xl border border-white/5 space-y-1.5"
              >
                <div className="flex justify-between font-bold text-white">
                  <span>{v.level}</span>
                  <span className="text-neon-cyan">{v.limit}</span>
                </div>
                <div className="flex justify-between text-[10px] text-gray-400">
                  <span>Service Fee:</span>
                  <span className="text-green-400">{v.fee}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
