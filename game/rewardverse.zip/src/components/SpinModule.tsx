import React, { useState, useRef } from "react";
import { UserProfile, WalletTransaction, SpinReward, SpinHistory } from "../types";
import { Disc, HelpCircle, History, RefreshCcw, LogIn, CheckSquare, Gift, Inbox } from "lucide-react";

interface SpinModuleProps {
  user: UserProfile;
  spinHistory: SpinHistory[];
  onUpdateUser: (newUser: UserProfile) => void;
  onAddTransaction: (tx: WalletTransaction) => void;
  onAddSpinHistory: (history: SpinHistory) => void;
  onTriggerToast: (msg: string, type: "success" | "info" | "error") => void;
}

const SPIN_REWARDS: SpinReward[] = [
  { id: 0, label: "🪙 100 Coins", value: 100, type: "coins", color: "#a855f7" },
  { id: 1, label: "⚡ 50 XP", value: 50, type: "xp", color: "#3b82f6" },
  { id: 2, label: "💵 $2.50 Cash", value: 2.5, type: "wallet", color: "#10b981" },
  { id: 3, label: "🎁 Mystery Box", value: 1, type: "mystery", color: "#fbbf24" },
  { id: 4, label: "🪙 500 Coins", value: 500, type: "coins", color: "#d946ef" },
  { id: 5, label: "⚡ 150 XP", value: 150, type: "xp", color: "#06b6d4" },
  { id: 6, label: "🔄 Bonus Spin", value: 1, type: "spin", color: "#ec4899" },
  { id: 7, label: "💵 $0.50 Cash", value: 0.5, type: "wallet", color: "#059669" }
];

export default function SpinModule({
  user,
  spinHistory,
  onUpdateUser,
  onAddTransaction,
  onAddSpinHistory,
  onTriggerToast
}: SpinModuleProps) {
  const [spinning, setSpinning] = useState<boolean>(false);
  const [rotationDegrees, setRotationDegrees] = useState<number>(0);
  const [spinsLeft, setSpinsLeft] = useState<number>(5);
  const [winningLabel, setWinningLabel] = useState<string | null>(null);

  const wheelRef = useRef<HTMLDivElement | null>(null);

  const handleSpinClick = () => {
    if (spinning) return;
    if (spinsLeft <= 0) {
      onTriggerToast("Daily spin limits completed! Re-calibrating in 12 hours.", "error");
      return;
    }

    setSpinning(true);
    setWinningLabel(null);
    setSpinsLeft((prev) => prev - 1);

    // Random choice among rewards
    const targetRewardIdx = Math.floor(Math.random() * SPIN_REWARDS.length);
    const chosenReward = SPIN_REWARDS[targetRewardIdx];

    // segment size of 45 deg (360 / 8 segments)
    // calculating mid rotation for high accuracy
    const segmentAngle = 360 / SPIN_REWARDS.length;
    // to land on segment targetRewardIdx we must rotate:
    // we want targetRewardIdx to land under the pointer at the top (which is 90 deg or 270 deg of wheel)
    // standard offset: segment 0 should land on pointer.
    const degreesToTarget = 360 - (targetRewardIdx * segmentAngle) - (segmentAngle / 2);

    // Add multiple rotations (e.g., 5 to 7 full circles) to build speed and duration
    const fullSpins = 5 * 360;
    const finalAngle = rotationDegrees + fullSpins + degreesToTarget;

    setRotationDegrees(finalAngle);

    setTimeout(() => {
      // Finished deceleration spin!
      setSpinning(false);
      setWinningLabel(chosenReward.label);
      applyReward(chosenReward);
    }, 4500); // 4.5 seconds matches transition animation perfectly
  };

  const applyReward = (reward: SpinReward) => {
    let outcomeText = "";
    
    onUpdateUser({
      ...user,
      coins: reward.type === "coins" ? user.coins + reward.value : user.coins,
      xp: reward.type === "xp" ? user.xp + reward.value : user.xp,
      walletBalance: reward.type === "wallet" ? user.walletBalance + reward.value : user.walletBalance
    });

    if (reward.type === "coins") {
      outcomeText = `Claimed +🪙${reward.value} Coins! Syncing ledger.`;
      const newTx: WalletTransaction = {
        id: `SP-${Math.floor(100000 + Math.random() * 900000)}`,
        type: "earn",
        amount: reward.value,
        currency: "coins",
        description: `Won Virtual coins in Spin Wheel`,
        timestamp: new Date().toISOString().replace("T", " ").substring(0, 19),
        status: "completed"
      };
      onAddTransaction(newTx);
    } else if (reward.type === "xp") {
      outcomeText = `Claimed +${reward.value} XP! Rank multiplier up.`;
    } else if (reward.type === "wallet") {
      outcomeText = `Claimed +$${reward.value.toFixed(2)} Cash inside Wallet!`;
      const newTx: WalletTransaction = {
        id: `SP-${Math.floor(100000 + Math.random() * 900000)}`,
        type: "earn",
        amount: reward.value,
        currency: "cash",
        description: `Won Cash reward in Spin Wheel`,
        timestamp: new Date().toISOString().replace("T", " ").substring(0, 19),
        status: "completed"
      };
      onAddTransaction(newTx);
    } else if (reward.type === "spin") {
      outcomeText = "Claimed +1 Free spins increment!";
      setSpinsLeft((prev) => prev + 1);
    } else if (reward.type === "mystery") {
      outcomeText = "Claimed Cyber Mystery Box! Unlocked key elements inside notified system.";
    }

    // Add to spin ledger list
    onAddSpinHistory({
      id: `SPH-${Math.floor(100000 + Math.random() * 900000)}`,
      timestamp: new Date().toLocaleTimeString(),
      rewardLabel: reward.label,
      type: reward.type,
      value: reward.value
    });

    onTriggerToast(outcomeText, "success");
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 select-none pb-20">
      {/* Route Header Badge */}
      <div className="lg:col-span-12 glass-panel p-4 flex justify-between items-center border border-neon-blue/20">
        <div className="flex items-center space-x-3">
          <Disc className="text-neon-pink w-5 h-5 animate-pulse" />
          <div>
            <span className="text-xs font-mono text-neon-pink block">DJANGO PLATFORM ROUTE:</span>
            <span className="text-sm font-bold text-white font-mono tracking-wide">/ui/spin/ [Vibration Wheel]</span>
          </div>
        </div>
        <div className="flex items-center space-x-2 text-xs font-mono">
          <span className="text-gray-400">Slots:</span>
          <span className="text-[#ec4899] font-bold">{spinsLeft} Spins Available Today</span>
        </div>
      </div>

      {/* Wheel Core Canvas (Left) */}
      <div className="col-span-1 lg:col-span-8 flex flex-col items-center">
        <div className="glass-panel p-6 sm:p-8 border border-white/5 bg-slate-900/40 w-full flex flex-col items-center relative overflow-hidden">
          <div className="absolute top-0 left-0 w-32 h-32 bg-neon-pink/5 rounded-full blur-2xl"></div>

          {/* Spinner Pin Pointer - Top Position */}
          <div className="relative w-72 h-72 sm:w-80 sm:h-80 my-6 flex justify-center items-center">
            {/* Ticker Pin SVG */}
            <div className="absolute top-[-10px] left-1/2 transform -translate-x-1/2 z-20 pointer-events-none spin-pin">
              <svg width="24" height="34" viewBox="0 0 24 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M12 0C5.37 0 0 5.37 0 12C0 21 12 34 12 34C12 34 24 21 24 12C24 5.37 18.63 0 12 0Z" fill="#ff4b82" />
                <circle cx="12" cy="12" r="5" fill="#ffffff" />
              </svg>
            </div>

            {/* Glowing outer bezel ring */}
            <div className="absolute inset-0 rounded-full border-4 border-neon-pink bg-black shadow-lg glow-purple pointer-events-none"></div>

            {/* Main Wheel Wrapper with transition */}
            <div
              ref={wheelRef}
              style={{
                transform: `rotate(${rotationDegrees}deg)`,
                transition: spinning ? "transform 4.5s cubic-bezier(0.15, 0.95, 0.35, 1)" : "none"
              }}
              className="absolute inset-[8px] rounded-full overflow-hidden flex items-center justify-center transition-transform"
            >
              <svg viewBox="0 0 200 200" className="w-full h-full transform -rotate-90">
                {SPIN_REWARDS.map((reward, idx) => {
                  const angle = 360 / SPIN_REWARDS.length;
                  const startAngle = idx * angle;
                  const endAngle = startAngle + angle;
                  // Calculate SVG arc paths
                  const radStart = (Math.PI * startAngle) / 180;
                  const radEnd = (Math.PI * endAngle) / 180;

                  const x1 = 100 + 100 * Math.cos(radStart);
                  const y1 = 100 + 100 * Math.sin(radStart);
                  const x2 = 100 + 100 * Math.cos(radEnd);
                  const y2 = 100 + 100 * Math.sin(radEnd);

                  // D: move to center (100,100), line to (x1,y1), arc to (x2,y2), close
                  const d = `M 100 100 L ${x1} ${y1} A 100 100 0 0 1 ${x2} ${y2} Z`;

                  // Calculate text placement coordinate
                  const textAngle = startAngle + angle / 2;
                  const radText = (Math.PI * textAngle) / 180;
                  const textX = 100 + 60 * Math.cos(radText);
                  const textY = 100 + 60 * Math.sin(radText);

                  return (
                    <g key={idx}>
                      <path d={d} fill={reward.color} opacity="0.82" className="stroke-slate-950/20 stroke-1" />
                      <text
                        x={textX}
                        y={textY}
                        fill="#ffffff"
                        fontSize="7"
                        fontWeight="bold"
                        fontFamily="monospace"
                        textAnchor="middle"
                        transform={`rotate(${textAngle}, ${textX}, ${textY})`}
                        alignmentBaseline="middle"
                      >
                        {reward.label.split(" ")[1] || reward.label}
                      </text>
                    </g>
                  );
                })}
              </svg>
            </div>

            {/* Inner neon core button */}
            <div
              onClick={handleSpinClick}
              className={`absolute w-16 h-16 rounded-full bg-slate-950 border-2 border-neon-cyan flex flex-col justify-center items-center cursor-pointer shadow-lg select-none z-10 active:scale-95 transition-all ${
                spinning ? "opacity-90 cursor-not-allowed" : "hover:border-white"
              }`}
            >
              <span className="text-[10px] font-extrabold font-mono text-neon-cyan select-none tracking-tight">
                {spinning ? "SPINNING" : "SPIN"}
              </span>
            </div>
          </div>

          {/* Show landing results */}
          {winningLabel && (
            <div className="mt-4 p-3 bg-neon-pink/15 border border-neon-pink/35 rounded-xl text-center flex flex-col items-center">
              <span className="text-[10px] font-mono uppercase tracking-widest text-[#ec4899] font-bold">OUTCOME RECIEVED</span>
              <span className="text-base font-extrabold text-[#ec4899] font-mono mt-1">{winningLabel}</span>
            </div>
          )}
        </div>
      </div>

      {/* Spin Limits/History (Right) */}
      <div className="col-span-1 lg:col-span-4 space-y-6">
        {/* Spin History ledger logs */}
        <div className="glass-panel p-6 border border-white/5 bg-slate-900/40 flex flex-col h-[400px]">
          <h3 className="font-bold text-sm uppercase text-gray-300 tracking-wider mb-4 font-mono flex items-center gap-1.5">
            <History className="w-4 h-4 text-neon-pink" /> SPIN RECORDS
          </h3>

          <div className="space-y-2 flex-1 overflow-y-auto pr-1">
            {spinHistory.length === 0 ? (
              <div className="text-center py-16 text-gray-500 font-mono text-xs">
                No past spins logged in current session.
              </div>
            ) : (
              spinHistory.map((h) => (
                <div
                  key={h.id}
                  className="p-3 bg-black/45 hover:bg-black/60 rounded-xl border border-white/5 flex justify-between items-center transition-all font-mono text-xs"
                >
                  <div className="space-y-0.5 max-w-[70%]">
                    <span className="font-semibold text-white truncate block">{h.rewardLabel}</span>
                    <span className="text-[9px] text-gray-500 block">{h.timestamp}</span>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <span className="px-1.5 py-0.5 bg-neon-pink/10 border border-neon-pink/20 text-neon-pink text-[9px] font-bold rounded">
                      WIN
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
