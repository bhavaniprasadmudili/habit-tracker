import React, { useState } from "react";
import { UserProfile, AppNotification } from "../types";
import { Bell, Check, Trash2, Shield, Info, Gift, Award, HelpCircle } from "lucide-react";

interface NotificationsModuleProps {
  notifications: AppNotification[];
  onMarkRead: (id: string) => void;
  onClearAll: () => void;
  onMarkAllRead: () => void;
}

export default function NotificationsModule({
  notifications,
  onMarkRead,
  onClearAll,
  onMarkAllRead
}: NotificationsModuleProps) {
  const [filter, setFilter] = useState<string>("all");

  const filteredNotifs = notifications.filter((n) => {
    if (filter === "all") return true;
    return n.type === filter;
  });

  const getIcon = (type: string) => {
    switch (type) {
      case "reward":
        return <Gift className="w-4 h-4 text-neon-gold" />;
      case "streak":
        return <Award className="w-4 h-4 text-neon-cyan" />;
      case "bonus":
        return <Award className="w-4 h-4 text-neon-purple animate-pulse" />;
      case "achievement":
        return <Award className="w-4 h-4 text-[#ec4899]" />;
      case "security":
        return <Shield className="w-4 h-4 text-neon-pink" />;
      default:
        return <Info className="w-4 h-4 text-gray-400" />;
    }
  };

  const getBorderColor = (type: string) => {
    switch (type) {
      case "reward":
        return "border-neon-gold/20";
      case "streak":
        return "border-neon-cyan/20";
      case "bonus":
        return "border-neon-purple/20";
      case "achievement":
        return "border-neon-pink/20";
      case "security":
        return "border-red-500/30 bg-red-950/5";
      default:
        return "border-white/5";
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 select-none pb-20">
      {/* Route Header Badge */}
      <div className="lg:col-span-12 glass-panel p-4 flex justify-between items-center border border-neon-blue/20">
        <div className="flex items-center space-x-3">
          <Bell className="text-neon-cyan w-5 h-5 animate-pulse" />
          <div>
            <span className="text-xs font-mono text-neon-cyan block">DJANGO PLATFORM ROUTE:</span>
            <span className="text-sm font-bold text-white font-mono tracking-wide">/ui/notifications/ [Alert Matrix]</span>
          </div>
        </div>

        {/* Action button rows */}
        <div className="flex space-x-2">
          <button
            onClick={onMarkAllRead}
            disabled={notifications.filter((n) => !n.read).length === 0}
            className="px-3 py-1.5 bg-white/5 border border-white/10 hover:bg-white/10 rounded-lg text-xs font-mono text-gray-300 disabled:opacity-40 transition-all flex items-center space-x-1"
          >
            <Check className="w-3.5 h-3.5" />
            <span>Mark read</span>
          </button>
          <button
            onClick={onClearAll}
            disabled={notifications.length === 0}
            className="px-3 py-1.5 bg-neon-pink/15 border border-neon-pink/20 hover:bg-neon-pink/25 text-neon-pink rounded-lg text-xs font-mono disabled:opacity-40 transition-all flex items-center space-x-1"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Wipe ledger</span>
          </button>
        </div>
      </div>

      {/* Sorting Rails (Left side) */}
      <div className="col-span-1 lg:col-span-3 space-y-2">
        <div className="glass-panel p-4 border border-white/5 bg-slate-900/40">
          <span className="text-[10px] font-mono tracking-widest text-neon-cyan uppercase font-bold block mb-3">
            Channels
          </span>
          <div className="space-y-1 font-mono text-xs">
            {[
              { id: "all", name: "All Alerts", count: notifications.length },
              { id: "reward", name: "🪙 Claims", count: notifications.filter((n) => n.type === "reward").length },
              { id: "streak", name: "🔥 Streak Bonus", count: notifications.filter((n) => n.type === "streak").length },
              { id: "achievement", name: "🏆 Badges", count: notifications.filter((n) => n.type === "achievement").length },
              { id: "security", name: "🛡️ Security Flag", count: notifications.filter((n) => n.type === "security").length }
            ].map((v) => (
              <button
                key={v.id}
                onClick={() => setFilter(v.id)}
                className={`w-full p-2.5 rounded-lg text-left flex justify-between items-center transition-all ${
                  filter === v.id
                    ? "bg-neon-cyan/20 text-white font-bold"
                    : "text-gray-400 hover:text-white hover:bg-white/5"
                }`}
              >
                <span>{v.name}</span>
                <span className="bg-black/40 px-1.5 py-0.5 rounded text-[9px] font-bold text-gray-400">
                  {v.count}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Active list notifications (Right side) */}
      <div className="col-span-1 lg:col-span-9 space-y-3.5">
        <div className="glass-panel p-5 border border-white/5 bg-slate-900/40 min-h-[350px]">
          <h3 className="font-mono text-xs text-slate-400 font-bold tracking-widest uppercase mb-4">
            LIVE SYSTEM TELEMETRY
          </h3>

          <div className="space-y-3">
            {filteredNotifs.length === 0 ? (
              <div className="text-center py-20 text-gray-500 font-mono text-xs">
                Your sandbox feed is pristine. No alerts registered.
              </div>
            ) : (
              filteredNotifs.map((notif) => (
                <div
                  key={notif.id}
                  onClick={() => onMarkRead(notif.id)}
                  className={`p-4 rounded-xl border flex items-start gap-4 transition-all duration-300 relative cursor-pointer ${getBorderColor(
                    notif.type
                  )} ${!notif.read ? "bg-slate-950/60 shadow glow-purple" : "bg-black/30 opacity-70"}`}
                >
                  {/* Unread indicator */}
                  {!notif.read && (
                    <span className="absolute left-1.5 top-1/2 transform -translate-y-1/2 w-1.5 h-1.5 bg-[#a855f7] rounded-full animate-ping"></span>
                  )}

                  {/* Channel icon */}
                  <div className="p-2.5 bg-black/40 border border-white/10 rounded-xl flex-shrink-0">
                    {getIcon(notif.type)}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-center gap-2">
                      <h4 className="font-bold text-xs sm:text-sm text-white font-mono truncate">
                        {notif.title}
                      </h4>
                      <span className="text-[9px] text-[#8e8a9f] font-mono flex-shrink-0">
                        {notif.timestamp}
                      </span>
                    </div>
                    <p className="text-xs text-gray-400 mt-1 leading-relaxed">
                      {notif.description}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
