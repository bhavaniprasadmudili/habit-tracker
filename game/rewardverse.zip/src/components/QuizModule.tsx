import React, { useState, useEffect, useRef } from "react";
import { UserProfile, WalletTransaction, QuizQuestion } from "../types";
import { Award, Timer, Volume2, HelpCircle, Check, X, Shield, ArrowRight, TrendingUp } from "lucide-react";

interface QuizModuleProps {
  user: UserProfile;
  onUpdateUser: (newUser: UserProfile) => void;
  onAddTransaction: (tx: WalletTransaction) => void;
  onTriggerToast: (msg: string, type: "success" | "info" | "error") => void;
  onNavigateToDashboard: () => void;
}

const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    question: "Which computer language is famously used as the backbone of Django templates and views server-side?",
    options: ["Ruby", "Python", "JavaScript", "Rust"],
    correctAnswerIndex: 1,
    coinsReward: 50,
    xpReward: 35
  },
  {
    id: 2,
    question: "In Django routing, which security variable or template tag protects standard AJAX post structures?",
    options: ["{% bypass_cors %}", "{% csrf_token %}", "{% session_hash %}", "{% secure_post %}"],
    correctAnswerIndex: 1,
    coinsReward: 50,
    xpReward: 40
  },
  {
    id: 3,
    question: "What does standard ORM stand for when pulling relational databases in Django models?",
    options: ["Object Relational Mapping", "Offline Resource Model", "Original Rest Matrix", "Our Retrieval Method"],
    correctAnswerIndex: 0,
    coinsReward: 50,
    xpReward: 45
  },
  {
    id: 4,
    question: "Which of these is the default development port typically bound for local Django web servers?",
    options: ["3000", "5000", "8000", "9000"],
    correctAnswerIndex: 2,
    coinsReward: 60,
    xpReward: 50
  },
  {
    id: 5,
    question: "Which ASGI / WSGI framework handles lightning-fast asynchronous tasks and worker queues in Django?",
    options: ["Nginx", "Celery + Redis", "Gunicorn", "SQLite3"],
    correctAnswerIndex: 1,
    coinsReward: 70,
    xpReward: 60
  }
];

export default function QuizModule({
  user,
  onUpdateUser,
  onAddTransaction,
  onTriggerToast,
  onNavigateToDashboard
}: QuizModuleProps) {
  const [currentIdx, setCurrentIdx] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isLocked, setIsLocked] = useState<boolean>(false);
  const [timeLeft, setTimeLeft] = useState<number>(15);
  const [score, setScore] = useState<number>(0);
  const [totalCoinsWon, setTotalCoinsWon] = useState<number>(0);
  const [totalXpWon, setTotalXpWon] = useState<number>(0);
  const [quizFinished, setQuizFinished] = useState<boolean>(false);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const activeQuestion = QUIZ_QUESTIONS[currentIdx];

  // Tick Timer
  useEffect(() => {
    if (quizFinished || isLocked) return;

    timerRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timerRef.current!);
          handleTimeOut();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [currentIdx, isLocked, quizFinished]);

  const handleTimeOut = () => {
    setIsLocked(true);
    setSelectedOption(-1); // Indication of timeout
    onTriggerToast("Time's up for this quest! Keep focused.", "info");
  };

  const handleOptionSelect = (optionIdx: number) => {
    if (isLocked) return;
    setIsLocked(true);
    setSelectedOption(optionIdx);

    const isCorrect = optionIdx === activeQuestion.correctAnswerIndex;

    if (isCorrect) {
      setScore((prev) => prev + 1);
      setTotalCoinsWon((prev) => prev + activeQuestion.coinsReward);
      setTotalXpWon((prev) => prev + activeQuestion.xpReward);
      onTriggerToast(`CORRECT! +🪙${activeQuestion.coinsReward} and +${activeQuestion.xpReward} XP!`, "success");
    } else {
      onTriggerToast("INCORRECT! Code audit failed on this option.", "error");
    }
  };

  const handleNextQuestion = () => {
    if (currentIdx + 1 < QUIZ_QUESTIONS.length) {
      setCurrentIdx((prev) => prev + 1);
      setSelectedOption(null);
      setIsLocked(false);
      setTimeLeft(15);
    } else {
      finishQuiz();
    }
  };

  const finishQuiz = () => {
    setQuizFinished(true);

    // Commit rewards
    const updatedCoins = user.coins + totalCoinsWon;
    onUpdateUser({
      ...user,
      coins: updatedCoins,
      xp: user.xp + totalXpWon
    });

    if (totalCoinsWon > 0) {
      const newTx: WalletTransaction = {
        id: `QZ-${Math.floor(100000 + Math.random() * 900000)}`,
        type: "earn",
        amount: totalCoinsWon,
        currency: "coins",
        description: `Daily Quiz Trivia Finished (${score}/${QUIZ_QUESTIONS.length})`,
        timestamp: new Date().toISOString().replace("T", " ").substring(0, 19),
        status: "completed"
      };
      onAddTransaction(newTx);
    }
  };

  const handleResetQuiz = () => {
    setCurrentIdx(0);
    setSelectedOption(null);
    setIsLocked(false);
    setTimeLeft(15);
    setScore(0);
    setTotalCoinsWon(0);
    setTotalXpWon(0);
    setQuizFinished(false);
  };

  const progressPercent = ((currentIdx + 1) / QUIZ_QUESTIONS.length) * 100;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 select-none pb-20">
      {/* Platform Header */}
      <div className="lg:col-span-12 glass-panel p-4 flex justify-between items-center border border-neon-blue/20">
        <div className="flex items-center space-x-3">
          <Award className="text-neon-purple w-5 h-5 animate-pulse" />
          <div>
            <span className="text-xs font-mono text-neon-purple block">DJANGO PLATFORM ROUTE:</span>
            <span className="text-sm font-bold text-white font-mono tracking-wide">/ui/quiz/ [Daily Trivia Port]</span>
          </div>
        </div>
        <div className="flex items-center space-x-2 text-xs font-mono">
          <span className="text-[#a855f7]">Quest Chain:</span>
          <span className="text-white font-bold">{currentIdx + 1} / {QUIZ_QUESTIONS.length}</span>
        </div>
      </div>

      {quizFinished ? (
        /* Quiz Finished Splash Card */
        <div className="lg:col-span-12 glass-panel p-8 sm:p-12 border border-neon-gold/35 bg-gradient-to-b from-[#1E1B4B]/30 to-black/60 text-center flex flex-col items-center">
          <div className="w-20 h-20 rounded-full bg-neon-gold/15 border-2 border-neon-gold/30 text-neon-gold flex justify-center items-center mb-6">
            <Award className="w-12 h-12 animate-pulse text-neon-gold" />
          </div>

          <h3 className="text-3xl font-extrabold text-white font-mono tracking-wide bg-gradient-to-r from-neon-gold via-white to-neon-purple bg-clip-text text-transparent">
            TRIVIA COMPILER SUCCESSFUL
          </h3>
          <p className="text-xs text-gray-300 mt-2 max-w-md leading-relaxed">
            You completed all questions in the sequence. Rewards have compiled and synced securely into our database.
          </p>

          {/* Stats details */}
          <div className="grid grid-cols-3 gap-4 w-full max-w-md mt-8 font-mono">
            <div className="bg-black/45 p-4 rounded-xl border border-white/5">
              <span className="text-[10px] text-gray-400 block">SCORE RATIO</span>
              <span className="text-base font-bold text-white mt-1 block">
                {score} / {QUIZ_QUESTIONS.length}
              </span>
            </div>
            <div className="bg-black/45 p-4 rounded-xl border border-white/5">
              <span className="text-[10px] text-neon-gold block">COINS EARNED</span>
              <span className="text-base font-bold text-neon-gold mt-1 block">
                +🪙{totalCoinsWon}
              </span>
            </div>
            <div className="bg-black/45 p-4 rounded-xl border border-white/5">
              <span className="text-[10px] text-neon-purple block">XP GRANTED</span>
              <span className="text-base font-bold text-neon-purple mt-1 block">
                +{totalXpWon} XP
              </span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-3 mt-10">
            <button
              onClick={handleResetQuiz}
              className="px-6 py-3 bg-neon-purple hover:bg-neon-purple/90 text-xs font-mono font-bold uppercase text-white rounded-xl shadow-lg transition-all"
            >
              Play Trivia Again
            </button>
            <button
              onClick={onNavigateToDashboard}
              className="px-6 py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-xs font-mono text-gray-300"
            >
              Return Home Dashboard
            </button>
          </div>
        </div>
      ) : (
        /* Quiz Active Card */
        <div className="lg:col-span-8 space-y-6">
          <div className="glass-panel p-6 sm:p-8 border border-white/5 bg-slate-900/40 relative">
            <div className="absolute top-0 right-0 w-44 h-44 bg-neon-purple/5 rounded-full blur-3xl"></div>

            {/* Timer and Header Info */}
            <div className="flex justify-between items-center mb-6">
              <div className="flex items-center space-x-2 text-xs font-mono">
                <span className="px-2 py-1 bg-white/5 border border-white/5 rounded text-gray-400">
                  Difficulty: Medium
                </span>
                <span className="px-2 py-1 bg-white/5 border border-white/5 rounded text-neon-cyan">
                  {activeQuestion.xpReward} XP Key
                </span>
              </div>

              {/* Countdown Dial */}
              <div
                className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-xl border font-mono text-sm font-bold tracking-tight ${
                  timeLeft <= 5
                    ? "bg-neon-pink/15 border-neon-pink text-neon-pink glow-cyan"
                    : "bg-black/35 border-white/10 text-white"
                }`}
              >
                <Timer className={`w-4 h-4 ${timeLeft <= 5 ? "animate-spin" : ""}`} />
                <span>{timeLeft}s</span>
              </div>
            </div>

            {/* Micro progress bar */}
            <div className="w-full h-1 bg-slate-950 rounded-full mb-6 overflow-hidden">
              <div
                className="bg-gradient-to-r from-neon-purple to-neon-cyan h-full transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              ></div>
            </div>

            {/* Question Card */}
            <div className="bg-black/30 rounded-2xl border border-white/5 p-6 mb-6">
              <div className="flex items-start space-x-3">
                <HelpCircle className="w-6 h-6 text-neon-purple flex-shrink-0 mt-0.5" />
                <h4 className="text-base sm:text-lg font-bold text-white leading-relaxed">
                  {activeQuestion.question}
                </h4>
              </div>
            </div>

            {/* Interactive Options Stack */}
            <div className="space-y-3 font-mono">
              {activeQuestion.options.map((opt, oIdx) => {
                const isSelected = selectedOption === oIdx;
                const isCorrect = oIdx === activeQuestion.correctAnswerIndex;
                const showCorrectGlow = isLocked && isCorrect;
                const showWrongGlow = isLocked && isSelected && !isCorrect;

                let btnStyles = "border-white/5 bg-white/5 hover:bg-white/10 text-gray-300";
                if (isSelected && !isLocked) {
                  btnStyles = "border-neon-purple bg-neon-purple/15 text-white";
                } else if (showCorrectGlow) {
                  btnStyles = "border-green-500 bg-green-500/10 text-green-400 glow-cyan font-bold";
                } else if (showWrongGlow) {
                  btnStyles = "border-neon-pink bg-neon-pink/10 text-neon-pink font-bold";
                }

                return (
                  <button
                    key={oIdx}
                    onClick={() => handleOptionSelect(oIdx)}
                    disabled={isLocked}
                    className={`w-full p-4 rounded-xl border text-left flex justify-between items-center transition-all duration-300 ${btnStyles}`}
                  >
                    <div className="flex items-center space-x-3.5">
                      <span className="w-6 h-6 rounded-lg bg-black/40 text-gray-400 text-xs font-bold font-mono flex items-center justify-center">
                        {String.fromCharCode(65 + oIdx)}
                      </span>
                      <span className="text-xs sm:text-sm font-medium">{opt}</span>
                    </div>

                    {/* Indicator Icon */}
                    {isLocked && (
                      <div className="flex-shrink-0">
                        {isCorrect ? (
                          <Check className="w-4 h-4 text-green-400" />
                        ) : isSelected ? (
                          <X className="w-4 h-4 text-neon-pink" />
                        ) : null}
                      </div>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Transition Row */}
            {isLocked && (
              <div className="mt-8 flex justify-end animate-fade-in">
                <button
                  onClick={handleNextQuestion}
                  className="px-5 py-3 bg-neon-cyan text-slate-950 font-bold font-mono text-xs uppercase tracking-wide rounded-xl flex items-center space-x-1.5 glow-cyan hover:bg-neon-cyan/95 active:scale-95 transition-all"
                >
                  <span>
                    {currentIdx + 1 === QUIZ_QUESTIONS.length ? "Finish Compile" : "Next Question"}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SLA Tiers Sidebar (Right) */}
      {!quizFinished && (
        <div className="col-span-1 lg:col-span-4 space-y-6">
          <div className="glass-panel p-6 border border-white/5 bg-slate-900/40">
            <h3 className="font-bold text-sm uppercase text-gray-300 tracking-wider mb-4 font-mono flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-neon-purple" /> TRIVIA CONTRACTS
            </h3>

            <div className="space-y-3 font-mono text-xs">
              <div className="p-3 bg-black/45 rounded-xl border border-white/5 space-y-1">
                <span className="text-slate-400 block text-[10px]">CURRENT COINS MULTIPLIER</span>
                <span className="text-base font-extrabold text-neon-gold block">1.0x (Regular)</span>
              </div>

              <div className="p-3 bg-black/45 rounded-xl border border-white/5 leading-relaxed text-gray-400 text-[11px] space-y-1">
                <span className="font-bold text-white text-xs block mb-1">Interactive Sandbox Rules</span>
                <p>&bull; Finish all 5 items to permanently transfer coins into your wallet profile.</p>
                <p>&bull; Timeouts count as incorrect answers.</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
