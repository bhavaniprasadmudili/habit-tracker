import React, { useState } from "react";
import { UserProfile, WalletTransaction, Task } from "../types";
import { CheckSquare, Star, Gift, Play, Share2, Clipboard, RefreshCw, CheckCircle2, Tv, AlertCircle } from "lucide-react";

interface TasksModuleProps {
  user: UserProfile;
  tasks: Task[];
  onUpdateUser: (newUser: UserProfile) => void;
  onUpdateTasks: (newTasks: Task[]) => void;
  onAddTransaction: (tx: WalletTransaction) => void;
  onTriggerToast: (msg: string, type: "success" | "info" | "error") => void;
}

export default function TasksModule({
  user,
  tasks,
  onUpdateUser,
  onUpdateTasks,
  onAddTransaction,
  onTriggerToast
}: TasksModuleProps) {
  const [activeCategory, setActiveCategory] = useState<"daily" | "social" | "challenge">("daily");
  const [vidPlaying, setVidPlaying] = useState<boolean>(false);
  const [vidProgress, setVidProgress] = useState<number>(0);
  const [activeAdTask, setActiveAdTask] = useState<string | null>(null);

  const handleClaim = (taskId: string) => {
    const targetTask = tasks.find((t) => t.id === taskId);
    if (!targetTask || !targetTask.isCompleted || targetTask.isClaimed) return;

    // Grant reward details
    const updatedUser = { ...user };
    if (targetTask.rewardType === "coins") {
      updatedUser.coins += targetTask.rewardValue;
    } else if (targetTask.rewardType === "xp") {
      updatedUser.xp += targetTask.rewardValue;
    } else if (targetTask.rewardType === "wallet") {
      updatedUser.walletBalance += targetTask.rewardValue;
    }

    onUpdateUser(updatedUser);

    // Create tx ledger
    const newTx: WalletTransaction = {
      id: `TSK-${Math.floor(100000 + Math.random() * 900000)}`,
      type: "earn",
      amount: targetTask.rewardValue,
      currency: targetTask.rewardType === "coins" ? "coins" : "cash",
      description: `Claimed quest: ${targetTask.title}`,
      timestamp: new Date().toISOString().replace("T", " ").substring(0, 19),
      status: "completed"
    };

    onAddTransaction(newTx);

    // Mark task as claimed
    const updatedTasks = tasks.map((t) => {
      if (t.id === taskId) {
        return { ...t, isClaimed: true };
      }
      return t;
    });

    onUpdateTasks(updatedTasks);
    onTriggerToast(`Quest Claimed! +${targetTask.rewardValue} ${targetTask.rewardType}`, "success");
  };

  const startVideoAdSim = (taskId: string) => {
    setVidPlaying(true);
    setVidProgress(0);
    setActiveAdTask(taskId);

    const interval = setInterval(() => {
      setVidProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          completeAdTask(taskId);
          return 100;
        }
        return prev + 20; // 5-second ticker
      });
    }, 1000);
  };

  const completeAdTask = (taskId: string) => {
    setTimeout(() => {
      setVidPlaying(false);
      setActiveAdTask(null);

      const nextTasks = tasks.map((t) => {
        if (t.id === taskId) {
          const newProg = Math.min(t.maxProgress, t.progress + 1);
          return {
            ...t,
            progress: newProg,
            isCompleted: newProg >= t.maxProgress
          };
        }
        return t;
      });

      onUpdateTasks(nextTasks);
      onTriggerToast("Hologram broadcast watched successfully! Reward claim ready.", "success");
    }, 600);
  };

  const handleStreakCheckIn = (dayIdx: number) => {
    const todayStr = new Date().toISOString().split("T")[0];
    const key = `day_${dayIdx}`;

    if (user.streakCalendar[key]) {
      onTriggerToast("This streak checkpoint is already claimed!", "info");
      return;
    }

    const coinReward = 150 + dayIdx * 50;
    const nextCalendar = { ...user.streakCalendar, [key]: true };

    onUpdateUser({
      ...user,
      streakCount: Math.min(7, user.streakCount + 1),
      coins: user.coins + coinReward,
      streakCalendar: nextCalendar
    });

    const newTx: WalletTransaction = {
      id: `STR-${Math.floor(100000 + Math.random() * 900000)}`,
      type: "bonus",
      amount: coinReward,
      currency: "coins",
      description: `Day ${dayIdx} Login Streak Bonus Claimed`,
      timestamp: new Date().toISOString().replace("T", " ").substring(0, 19),
      status: "completed"
    };

    onAddTransaction(newTx);
    onTriggerToast(`Streak Day ${dayIdx} complete! +🪙${coinReward} coins added.`, "success");
  };

  const handleSocialSim = (taskId: string) => {
    // Simulate social triggers (Copy dynamic invite link)
    navigator.clipboard.writeText("https://rewardverse.io/invite?code=GAMERZERO");
    onTriggerToast("Dynamic referral node link copied to clip-board!", "info");

    const nextTasks = tasks.map((t) => {
      if (t.id === taskId) {
        return { ...t, progress: t.maxProgress, isCompleted: true };
      }
      return t;
    });
    onUpdateTasks(nextTasks);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 select-none pb-20">
      {/* Route Header Badge */}
      <div className="lg:col-span-12 glass-panel p-4 flex justify-between items-center border border-neon-blue/20">
        <div className="flex items-center space-x-3">
          <CheckSquare className="text-neon-cyan w-5 h-5 animate-pulse" />
          <div>
            <span className="text-xs font-mono text-neon-cyan block">DJANGO PLATFORM ROUTE:</span>
            <span className="text-sm font-bold text-white font-mono tracking-wide">/ui/tasks/ [Quest Catalyst]</span>
          </div>
        </div>
        <div className="flex space-x-2">
          {["daily", "social", "challenge"].map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat as any)}
              className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold uppercase transition-all ${
                activeCategory === cat
                  ? "bg-neon-purple text-white shadow glow-purple"
                  : "bg-white/5 text-gray-400 hover:text-white"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Login Streak Board Calendar (Center left block) */}
      <div className="col-span-1 lg:col-span-12 space-y-6">
        <div className="glass-panel p-6 border border-[#fbbf24]/20 bg-gradient-to-r from-amber-950/10 via-slate-900/40 to-slate-900/40 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-neon-gold/5 rounded-full blur-2xl"></div>

          <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 mb-6">
            <div>
              <h3 className="font-bold text-base text-white font-mono tracking-wide flex items-center gap-1.5">
                <Star className="w-5 h-5 text-neon-gold animate-bounce" /> 7-DAY STREAK CATALYST
              </h3>
              <p className="text-xs text-gray-400">Claim coins daily to feed your consecutive logging streak.</p>
            </div>
            {/* Streak count bubble */}
            <div className="px-3 py-1.5 bg-neon-gold/15 border border-neon-gold/30 text-[#fbbf24] font-mono text-xs rounded-xl font-bold flex items-center space-x-1">
              <span>🔥 Streak Speed:</span>
              <span className="text-white">{user.streakCount} / 7 Days</span>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-7 gap-3">
            {Array.from({ length: 7 }).map((_, idx) => {
              const dayNum = idx + 1;
              const key = `day_${dayNum}`;
              const claimed = user.streakCalendar[key] === true;
              const isActive = user.streakCount === idx;

              return (
                <div
                  key={idx}
                  onClick={() => handleStreakCheckIn(dayNum)}
                  className={`p-3.5 rounded-2xl border text-center transition-all cursor-pointer relative ${
                    claimed
                      ? "border-green-500/30 bg-green-500/10 text-green-400"
                      : isActive
                      ? "border-neon-gold bg-neon-gold/20 text-white animate-pulse"
                      : "border-white/5 bg-slate-950/40 hover:border-white/20 text-gray-400"
                  }`}
                >
                  <span className="text-[10px] font-mono block tracking-wider font-bold">DAY {dayNum}</span>
                  <span className="text-xl my-2 block">
                    {claimed ? "✅" : dayNum === 7 ? "👑" : "💎"}
                  </span>
                  <span className="text-[10px] font-mono block">
                    {claimed ? "Claimed" : `+🪙${150 + dayNum * 50}`}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Quest list tasks (Left bottom block) */}
      <div className="col-span-1 lg:col-span-8 space-y-4">
        {/* Hologram Video Player Ad Simulator Drawer */}
        {vidPlaying && (
          <div className="glass-panel p-6 border-2 border-neon-cyan/40 bg-black/95 text-center flex flex-col items-center justify-center relative shadow-2xl z-30 animate-fade-in mb-6">
            <Tv className="w-10 h-10 text-neon-cyan animate-pulse mb-3" />
            <h4 className="font-mono text-sm font-bold text-white uppercase tracking-widest">
              Gamer Ads stream buffer active
            </h4>
            <p className="text-xs text-gray-400 max-w-sm mt-1 mb-6 font-mono">
              Do not shut this gateway. Syncing ad-impression pixel.
            </p>

            {/* Simulated frame with rotating progress */}
            <div className="w-full max-w-sm bg-slate-900 border border-white/10 p-10 rounded-xl relative overflow-hidden flex justify-center items-center">
              <div className="text-neon-cyan text-xs font-mono select-none h-16 flex items-center justify-center">
                {vidProgress < 100 ? (
                  <span className="text-base font-bold animate-ping uppercase">
                    LOADING STREAM {vidProgress}%
                  </span>
                ) : (
                  <span className="text-bold text-green-400 uppercase">
                    VALIDATION SIGNAL OK
                  </span>
                )}
              </div>
              <div
                className="absolute bottom-0 left-0 bg-neon-cyan h-1 transition-all duration-1000"
                style={{ width: `${vidProgress}%` }}
              ></div>
            </div>
          </div>
        )}

        {/* Task List items */}
        {tasks
          .filter((t) => t.category === activeCategory)
          .map((task) => {
            const isCompleted = task.isCompleted;
            const isClaimed = task.isClaimed;

            return (
              <div
                key={task.id}
                className={`p-4 sm:p-5 glass-panel border bg-slate-900/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all duration-300 ${
                  isClaimed
                    ? "opacity-60 border-white/5"
                    : isCompleted
                    ? "border-green-500/20 shadow-lg shadow-green-500/5 glow-purple"
                    : "border-white/5 hover:border-white/15"
                }`}
              >
                <div className="flex items-start space-x-3.5 max-w-[70%]">
                  <div className="p-2.5 bg-black/40 border border-white/10 rounded-xl text-neon-cyan flex-shrink-0">
                    <CheckSquare className="w-5 h-5 text-neon-cyan" />
                  </div>
                  <div>
                    <h4 className="font-bold text-xs sm:text-sm text-white font-mono tracking-tight flex items-center gap-1.5">
                      {task.title}
                      {isClaimed && (
                        <span className="text-[9px] bg-green-500/20 text-green-400 border border-green-500/30 font-bold px-1.5 py-0.5 rounded uppercase">
                          Claimed
                        </span>
                      )}
                    </h4>
                    <p className="text-xs text-gray-400 mt-1 leading-relaxed">{task.description}</p>

                    {/* Progress details */}
                    <div className="flex items-center space-x-2 mt-3 font-mono text-[10px] text-gray-500">
                      <span>Progress:</span>
                      <div className="w-24 h-1.5 bg-slate-950 rounded-full overflow-hidden">
                        <div
                          className="bg-neon-cyan h-full transition-all"
                          style={{ width: `${(task.progress / task.maxProgress) * 100}%` }}
                        ></div>
                      </div>
                      <span className="text-neon-cyan font-semibold">
                        {task.progress} / {task.maxProgress}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Claim / Watch Activator Buttons */}
                <div className="flex-shrink-0 text-right sm:self-center">
                  {!isCompleted ? (
                    task.iconName === "Tv" ? (
                      <button
                        onClick={() => startVideoAdSim(task.id)}
                        disabled={vidPlaying}
                        className="w-full sm:w-auto px-4 py-2.5 bg-neon-cyan hover:bg-neon-cyan/95 text-slate-950 font-bold font-mono text-xs uppercase tracking-wide rounded-xl flex items-center justify-center space-x-1.5 glow-cyan"
                      >
                        <Tv className="w-3.5 h-3.5" />
                        <span>Stream Ad</span>
                      </button>
                    ) : task.iconName === "Share2" ? (
                      <button
                        onClick={() => handleSocialSim(task.id)}
                        className="w-full sm:w-auto px-4 py-2.5 bg-neon-purple hover:bg-neon-purple/95 text-white font-bold font-mono text-xs uppercase tracking-wide rounded-xl flex items-center justify-center space-x-1.5 glow-purple"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                        <span>Invite Node</span>
                      </button>
                    ) : (
                      <div className="text-[11px] text-[#fbbf24] font-mono flex items-center gap-1">
                        <AlertCircle className="w-3.5 h-3.5" /> Awaiting Gameplay
                      </div>
                    )
                  ) : (
                    <button
                      onClick={() => handleClaim(task.id)}
                      disabled={isClaimed}
                      className={`w-full sm:w-auto px-5 py-2.5 rounded-xl text-xs font-mono font-bold uppercase transition-all ${
                        isClaimed
                          ? "bg-stone-900 border border-white/5 text-gray-500 cursor-not-allowed"
                          : "bg-green-500 text-slate-950 hover:bg-green-400 glow-cyan animate-pulse"
                      }`}
                    >
                      {isClaimed ? "QUEST COMPLETED" : "CLAIM REWARD &bull; 🪙" + task.rewardValue}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
      </div>

      {/* Info Rules sidebar block (Right bottom block) */}
      <div className="col-span-1 lg:col-span-4 space-y-6">
        <div className="glass-panel p-6 border border-white/5 bg-slate-900/40">
          <h3 className="font-bold text-sm uppercase text-gray-300 tracking-wider mb-4 font-mono flex items-center gap-1.5">
            <Gift className="w-4 h-4 text-neon-cyan" /> ESCROW POLICY
          </h3>

          <div className="space-y-4 font-mono text-xs leading-relaxed text-gray-400">
            <p className="p-3 bg-black/45 rounded-xl border border-white/5 text-[11px]">
              &bull; Quest rewards compile instantly.
            </p>
            <p className="p-3 bg-black/45 rounded-xl border border-white/5 text-[11px]">
              &bull; Using browser tools or scripts to auto-submit ad-verification tokens will engage the anti-cheat telemetry instantly.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
