import React, { useEffect, useRef } from "react";

interface ConfettiProps {
  active: boolean;
  onAnimationComplete?: () => void;
}

interface Particle {
  x: number;
  y: number;
  size: number;
  color: string;
  speedX: number;
  speedY: number;
  rotation: number;
  rotationSpeed: number;
  opacity: number;
}

export default function Confetti({ active, onAnimationComplete }: ConfettiProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const particlesRef = useRef<Particle[]>([]);
  const animationFrameRef = useRef<number | null>(null);

  const colors = ["#a855f7", "#3b82f6", "#06b6d4", "#ec4899", "#fbbf24", "#10b981"];

  useEffect(() => {
    if (!active) {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      particlesRef.current = [];
      return;
    }

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Set Canvas scale
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    // Generate burst of particles
    const list: Particle[] = [];
    for (let i = 0; i < 90; i++) {
      list.push({
        x: canvas.width / 2,
        y: canvas.height * 0.75, // burst from near the bottom-middle of viewport
        size: Math.random() * 8 + 4,
        color: colors[Math.floor(Math.random() * colors.length)],
        speedX: (Math.random() - 0.5) * 16,
        speedY: -Math.random() * 18 - 8,
        rotation: Math.random() * 360,
        rotationSpeed: (Math.random() - 0.5) * 10,
        opacity: 1
      });
    }
    particlesRef.current = list;

    // Physics ticks
    const renderTick = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      let activeParticles = 0;

      particlesRef.current.forEach((p) => {
        p.x += p.speedX;
        p.y += p.speedY;
        p.speedY += 0.35; // Gravity pull
        p.speedX *= 0.98; // Air resistance friction
        p.rotation += p.rotationSpeed;

        if (p.speedY > 0) {
          p.opacity -= 0.012; // slowly dissolve as they fall
        }

        if (p.opacity > 0 && p.y < canvas.height && p.x > 0 && p.x < canvas.width) {
          activeParticles++;

          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.rotate((p.rotation * Math.PI) / 180);
          ctx.fillStyle = p.color;
          ctx.globalAlpha = p.opacity;
          ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
          ctx.restore();
        }
      });

      if (activeParticles > 0) {
        animationFrameRef.current = requestAnimationFrame(renderTick);
      } else {
        if (onAnimationComplete) {
          onAnimationComplete();
        }
      }
    };

    renderTick();

    const handleResize = () => {
      if (!canvas) return;
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    window.addEventListener("resize", handleResize);
    return () => {
      window.removeEventListener("resize", handleResize);
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [active]);

  if (!active) return null;

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none z-50 h-full w-full"
    />
  );
}
