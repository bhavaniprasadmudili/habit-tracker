import React, { useState } from "react";
import { UserProfile, WalletTransaction } from "../types";
import { Wallet, CircleDollarSign, ArrowLeftRight, RefreshCcw, TrendingUp, History, Download, Calendar } from "lucide-react";

interface WalletModuleProps {
  user: UserProfile;
  transactions: WalletTransaction[];
  onUpdateUser: (newUser: UserProfile) => void;
  onAddTransaction: (tx: WalletTransaction) => void;
  onTriggerToast: (msg: string, type: "success" | "info" | "error") => void;
  onNavigateToPayouts: () => void;
}

export default function WalletModule({
  user,
  transactions,
  onUpdateUser,
  onAddTransaction,
  onTriggerToast,
  onNavigateToPayouts
}: WalletModuleProps) {
  const [exchangeAmount, setExchangeAmount] = useState<number>(1000);
  const conversionRate = 1000; // 1000 coins = $1.00 USD

  const handleConvertCoins = () => {
    if (user.coins < exchangeAmount) {
      onTriggerToast("Insufficient coins for exchange conversion!", "error");
      return;
    }

    const usdEarned = exchangeAmount / conversionRate;
    const remainingCoins = user.coins - exchangeAmount;
    const newWalletBalance = user.walletBalance + usdEarned;

    onUpdateUser({
      ...user,
      coins: remainingCoins,
      walletBalance: newWalletBalance
    });

    const newTx: WalletTransaction = {
      id: `TX-${Math.floor(100000 + Math.random() * 900000)}`,
      type: "earn",
      amount: usdEarned,
      currency: "cash",
      description: `Exchanged ${exchangeAmount} Gold Coins (Converter)`,
      timestamp: new Date().toISOString().replace("T", " ").substring(0, 19),
      status: "completed"
    };

    onAddTransaction(newTx);
    onTriggerToast(`Exchanged ${exchangeAmount} coins for $${usdEarned.toFixed(2)} cash!`, "success");
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 select-none pb-20">
      {/* Route Badge Header */}
      <div className="lg:col-span-12 glass-panel p-4 flex justify-between items-center border border-neon-blue/20">
        <div className="flex items-center space-x-3">
          <Wallet className="text-neon-cyan w-5 h-5 animate-pulse" />
          <div>
            <span className="text-xs font-mono text-neon-cyan block">DJANGO PLATFORM ROUTE:</span>
            <span className="text-sm font-bold text-white font-mono tracking-wide">/ui/wallet/ [Audit Vault]</span>
          </div>
        </div>
        <div className="flex items-center space-x-2 text-xs font-mono">
          <span className="text-gray-400">Escrow:</span>
          <span className="text-emerald-400 font-bold">$14,204.00</span>
        </div>
      </div>

      {/* Vault Balance Cards (Left) */}
      <div className="col-span-1 lg:col-span-4 space-y-6">
        {/* USD Wallet Balance */}
        <div className="glass-panel p-6 border border-emerald-500/20 bg-gradient-to-br from-emerald-950/10 via-slate-900/40 to-slate-900/40 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-2xl group-hover:bg-emerald-500/10 transition-colors"></div>
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-mono uppercase text-emerald-400 font-semibold tracking-wider">
                Total Wallet Balance
              </p>
              <h2 className="text-4xl font-extrabold font-mono text-white tracking-tight mt-2 text-glow-cyan">
                ${user.walletBalance.toFixed(2)}
              </h2>
            </div>
            <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl text-emerald-400">
              <CircleDollarSign className="w-6 h-6" />
            </div>
          </div>
          <p className="text-xs text-gray-400 mt-4 leading-relaxed font-mono">
            &bull; Approved for instant cash withdrawals
          </p>

          <button
            onClick={onNavigateToPayouts}
            className="w-full mt-4 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 rounded-xl text-xs font-mono font-bold uppercase text-slate-950 shadow glow-cyan active:scale-[0.98] transition-all"
          >
            Claim Payout Now &rarr;
          </button>
        </div>

        {/* Gold Coin Balance */}
        <div className="glass-panel p-6 border border-neon-gold/20 bg-gradient-to-br from-amber-950/10 via-slate-900/40 to-slate-900/40 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-neon-gold/5 rounded-full blur-2xl group-hover:bg-neon-gold/10 transition-colors"></div>
          <div className="flex justify-between items-start">
            <div>
              <p className="text-xs font-mono uppercase text-[#fbbf24] font-semibold tracking-wider">
                Virtual Coin Vault
              </p>
              <h2 className="text-4xl font-extrabold font-mono text-white tracking-tight mt-2 text-glow-gold">
                🪙 {user.coins}
              </h2>
            </div>
            <div className="p-3 bg-amber-500/10 border border-neon-gold/20 rounded-2xl text-[#fbbf24]">
              <TrendingUp className="w-6 h-6" />
            </div>
          </div>
          <p className="text-xs text-gray-400 mt-4 leading-relaxed font-mono">
            &bull; Earned via Quests, Spins, and Quizzes
          </p>
        </div>
      </div>

      {/* Coin Conversion Converter (Center) */}
      <div className="col-span-1 lg:col-span-4 space-y-6">
        <div className="glass-panel p-6 border border-neon-purple/20 bg-slate-900/40 relative">
          <div className="absolute top-0 right-0 w-32 h-32 bg-neon-purple/5 rounded-full blur-2xl"></div>
          <h3 className="font-bold text-sm uppercase text-gray-300 tracking-wider mb-2 font-mono flex items-center gap-1.5">
            <ArrowLeftRight className="w-4 h-4 text-neon-purple" /> COIN CONVERT ENGINE
          </h3>
          <p className="text-xs text-gray-400 mb-5 leading-relaxed">
            Convert virtual gaming coins into spendable dollars. Instantly injected into your wallet node.
          </p>

          <div className="space-y-4 font-mono text-xs">
            <div className="bg-black/35 rounded-xl border border-white/5 p-4 flex justify-between items-center text-center">
              <div>
                <span className="text-[10px] text-gray-400 block uppercase">Conversion Ratio</span>
                <span className="text-sm font-bold text-white mt-1 block">1,000 Coins</span>
              </div>
              <span className="text-neon-cyan font-bold text-base">&hArr;</span>
              <div>
                <span className="text-[10px] text-gray-400 block uppercase">Cash Yield</span>
                <span className="text-sm font-bold text-green-400 mt-1 block">$1.00 USD</span>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[11px] text-gray-400 block uppercase font-bold">COINS TO LIQUIDATE</label>
              <div className="grid grid-cols-3 gap-2">
                {[1000, 5000, 10000].map((val) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => setExchangeAmount(val)}
                    className={`p-2 rounded-lg border text-center transition-all ${
                      exchangeAmount === val
                        ? "border-neon-purple bg-neon-purple/20 text-white font-bold"
                        : "border-white/5 bg-white/5 text-gray-400 hover:text-white"
                    }`}
                  >
                    {val.toLocaleString()}
                  </button>
                ))}
              </div>
            </div>

            <div className="bg-slate-950/80 rounded-xl p-3 border border-white/5 flex items-center justify-between text-[11px]">
              <span className="text-gray-400">Available Coins:</span>
              <span className="text-neon-gold font-bold">🪙 {user.coins}</span>
            </div>

            <button
              onClick={handleConvertCoins}
              className="w-full py-3 bg-neon-purple hover:bg-neon-purple/95 text-xs font-bold uppercase tracking-wider text-white shadow-lg glow-purple rounded-xl transition-all"
            >
              Convert to Cash Now
            </button>
          </div>
        </div>
      </div>

      {/* Ledger History List (Right) */}
      <div className="col-span-1 lg:col-span-4 space-y-6">
        <div className="glass-panel p-6 border border-white/5 bg-slate-900/40 flex flex-col h-[400px]">
          <h3 className="font-bold text-sm uppercase text-gray-300 tracking-wider mb-4 font-mono flex items-center gap-1.5">
            <History className="w-4 h-4 text-neon-cyan" /> REWARD LEDGER HISTORY
          </h3>

          <div className="space-y-2 flex-1 overflow-y-auto pr-1">
            {transactions.length === 0 ? (
              <div className="text-center py-12 text-gray-500 font-mono text-xs">
                No past ledger movements detected.
              </div>
            ) : (
              transactions.map((tx) => (
                <div
                  key={tx.id}
                  className="p-3 bg-black/45 hover:bg-black/60 rounded-xl border border-white/5 flex justify-between items-center transition-all font-mono text-xs"
                >
                  <div className="space-y-0.5 max-w-[70%]">
                    <span className="font-semibold text-white truncate block">{tx.description}</span>
                    <span className="text-[9px] text-gray-500 block">{tx.timestamp}</span>
                  </div>
                  <div className="text-right">
                    <span
                      className={`font-semibold text-sm ${
                        tx.type === "earn" || tx.type === "bonus" ? "text-green-400" : "text-neon-pink"
                      }`}
                    >
                      {tx.type === "earn" || tx.type === "bonus" ? "+" : "-"}
                      {tx.currency === "coins" ? `🪙${tx.amount}` : `$${tx.amount.toFixed(2)}`}
                    </span>
                    <span className="text-[8px] uppercase tracking-wider block text-gray-400 mt-0.5">
                      {tx.id}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
