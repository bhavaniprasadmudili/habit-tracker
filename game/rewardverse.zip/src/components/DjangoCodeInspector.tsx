import React, { useState } from "react";
import { Terminal, Shield, Cpu, Code, Copy, Check, FileText } from "lucide-react";

interface DjangoCodeInspectorProps {
  onClose?: () => void;
}

type CodeTab = "models" | "views" | "templates" | "ajax";

export default function DjangoCodeInspector({ onClose }: DjangoCodeInspectorProps) {
  const [activeTab, setActiveTab] = useState<CodeTab>("models");
  const [selectedModule, setSelectedModule] = useState<string>("quiz");
  const [copied, setCopied] = useState<boolean>(false);

  const triggerCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const modules = [
    { id: "quiz", name: "Daily Quiz" },
    { id: "spin", name: "Spin Wheel" },
    { id: "guess", name: "Guess & Win" },
    { id: "wallet", name: "Wallet & Cashout" },
    { id: "tasks", name: "Task Tracker" },
    { id: "fraud", name: "Anti-Cheat Audit" }
  ];

  const getCodeContent = (): string => {
    if (activeTab === "models") {
      return `from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

class RewardProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="profile")
    level = models.IntegerField(default=1)
    xp = models.IntegerField(default=0)
    coins = models.IntegerField(default=0)
    wallet_balance = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    streak_count = models.IntegerField(default=0)
    last_active = models.DateField(auto_now=True)
    is_verified = models.BooleanField(default=False)
    security_score = models.IntegerField(default=100)
    device_fingerprint = models.CharField(max_length=255, blank=True, null=True)

    def add_xp(self, amount):
        self.xp += amount
        xp_needed = self.level * 100
        while self.xp >= xp_needed:
            self.xp -= xp_needed
            self.level += 1
            xp_needed = self.level * 100
        self.save()

class RewardTask(models.Model):
    TASK_TYPES = [
        ('daily', 'Daily Login'),
        ('quiz', 'Complete Quiz'),
        ('spin', 'Daily Spin'),
        ('invite', 'Invite Friends'),
    ]
    title = models.CharField(max_length=150)
    reward_type = models.CharField(max_length=20, default="coins")
    reward_value = models.IntegerField(default=10)
    is_active = models.BooleanField(default=True)

class RewardHistory(models.Model):
    profile = models.ForeignKey(RewardProfile, on_delete=models.CASCADE, related_name="earnings")
    action_name = models.CharField(max_length=100)
    reward_amount = models.DecimalField(max_digits=10, decimal_places=2)
    currency_type = models.CharField(max_length=10, choices=[('coins', 'Coins'), ('cash', 'Cash')])
    timestamp = models.DateTimeField(default=timezone.now)
`;
    }

    if (activeTab === "views") {
      switch (selectedModule) {
        case "quiz":
          return `from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json

@csrf_exempt # In production, verify CSRF token
def check_quiz_answer(request):
    if request.method != "POST":
        return JsonResponse({"error": "Invalid request method"}, status=400)
        
    try:
        data = json.loads(request.body)
        question_id = data.get("question_id")
        selected_option = data.get("selected_option")
        
        # Verify user state
        profile = request.user.profile
        
        # Simulating reward validation
        correct = (int(selected_option) == 1) # Example correct index check
        if correct:
            profile.coins += 25
            profile.add_xp(40)
            profile.save()
            return JsonResponse({
                "status": "success",
                "correct": True,
                "reward_coins": 25,
                "reward_xp": 40,
                "new_balance": profile.coins
            })
        return JsonResponse({"status": "success", "correct": False})
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)
`;
        case "spin":
          return `import random
from django.http import JsonResponse

def process_spin_claim(request):
    if not request.user.is_authenticated:
        return JsonResponse({"error": "Auth required"}, status=401)
        
    profile = request.user.profile
    
    # Simple probability-weighted system for spin rewards
    # 0: Coins, 1: XP, 2: Bonus Spin, 3: Cash, 4: Mystery Box
    rewards_pool = [
        {"id": 0, "label": "50 Coins", "type": "coins", "val": 50, "weight": 40},
        {"id": 1, "label": "100 XP", "type": "xp", "val": 100, "weight": 35},
        {"id": 2, "label": "Super Mystery", "type": "mystery", "val": 1, "weight": 15},
        {"id": 3, "label": "$5.00 Cash", "type": "wallet", "val": 5, "weight": 10},
    ]
    
    # Weight random selection
    choices = []
    for r in rewards_pool:
        choices.extend([r] * r["weight"])
        
    outcome = random.choice(choices)
    
    # Save earnings
    if outcome["type"] == "coins":
        profile.coins += outcome["val"]
    elif outcome["type"] == "xp":
        profile.add_xp(outcome["val"])
    elif outcome["type"] == "wallet":
        profile.wallet_balance += outcome["val"]
        
    profile.save()
    
    return JsonResponse({
        "status": "won",
        "reward_id": outcome["id"],
        "reward_label": outcome["label"],
        "reward_type": outcome["type"],
        "reward_val": outcome["val"],
        "user_coins": profile.coins,
        "user_balance": float(profile.wallet_balance)
    })
`;
        case "tasks":
          return `from django.http import JsonResponse
from django.contrib.auth.decorators import login_required

@login_required
def claim_task_reward(request, task_id):
    profile = request.user.profile
    # Verify task progress with DB
    try:
        task = RewardTask.objects.get(id=task_id)
        # Verify not claimed
        # ... logic to check user-task completion relationship ...
        
        # Grant rewards
        if task.reward_type == "coins":
            profile.coins += task.reward_value
        elif task.reward_type == "xp":
            profile.add_xp(task.reward_value)
        profile.save()
        
        return JsonResponse({
            "status": "claimed",
            "coins": profile.coins,
            "xp": profile.xp
        })
    except RewardTask.DoesNotExist:
        return JsonResponse({"error": "Task not found"}, status=404)
`;
        case "wallet":
          return `from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from decimal import Decimal

@login_required
def submit_withdrawal(request):
    if request.method == "POST":
        import json
        data = json.loads(request.body)
        amount = Decimal(str(data.get("amount", 0)))
        method = data.get("method", "paypal")
        payout_address = data.get("payout_address")
        
        profile = request.user.profile
        if profile.wallet_balance < amount:
            return JsonResponse({"error": "Insufficient funds"}, status=400)
        
        if profile.security_score < 60:
            return JsonResponse({"status": "blocked", "reason": "Requires verification due to suspicious activity score."})
            
        # Deduct balance & create Ledger
        profile.wallet_balance -= amount
        profile.save()
        
        # Create request log...
        return JsonResponse({
            "status": "pending",
            "message": "Withdrawal request submitted for review",
            "remaining_balance": float(profile.wallet_balance)
        })
    return JsonResponse({"error": "POST method required"}, status=400)
`;
        case "fraud":
          return `from django.http import JsonResponse
from django.contrib.auth.decorators import login_required

@login_required
def process_anti_cheat_check(request):
    profile = request.user.profile
    user_agent = request.META.get('HTTP_USER_AGENT', '')
    ip_address = request.META.get('REMOTE_ADDR', '')
    
    suspicious = False
    reasons = []
    
    # Standard anti-cheat telemetry
    # Check if this IP is holding multiple accounts
    # ...
    
    if "Postman" in user_agent or "curl" in user_agent:
        suspicious = True
        reasons.append("Non-browser environment detected")
        profile.security_score = max(0, profile.security_score - 30)
    
    if profile.security_score < 50:
        profile.is_verified = False
        
    profile.save()
    
    return JsonResponse({
        "status": "audited",
        "security_score": profile.security_score,
        "is_verified": profile.is_verified,
        "suspicious_flag": suspicious,
        "reasons": reasons
    })
`;
        default:
          return `# Generic View Endpoint
def general_info(request):
    return JsonResponse({"status": "active","platform": "RewardVerse Django"})`;
      }
    }

    if (activeTab === "templates") {
      return `{% extends "base.html" %}
{% load static %}

{% block content %}
<!-- RewardVerse Neon Container -->
<div class="min-h-screen bg-slate-950 text-white font-sans p-4">
    <!-- Dynamic Header Plate -->
    <div class="flex justify-between items-center bg-gray-900/40 border border-white/10 rounded-2xl p-4 backdrop-blur-md mb-6">
        <div class="flex items-center space-x-3">
            <div class="relative">
                <img src="{{ user.profile.avatar }}" class="w-12 h-12 rounded-full border-2 border-purple-500 shadow-lg" alt="Profile">
                <span class="absolute -bottom-1 -right-1 bg-yellow-400 text-slate-950 font-bold px-1.5 py-0.5 rounded-full text-xs">
                    Lvl {{ user.profile.level }}
                </span>
            </div>
            <div>
                <h4 class="font-bold tracking-wide text-white">{{ user.username }}</h4>
                <div class="flex items-center space-x-2 text-xs text-purple-400 mt-1">
                    <span class="px-1.5 py-0.5 bg-purple-500/20 rounded border border-purple-500/30">Rank #{{ user.profile.rank }}</span>
                    {% if user.profile.is_verified %}
                    <span class="text-green-400 font-bold flex items-center">✓ Verified</span>
                    {% endif %}
                </div>
            </div>
        </div>
        
        <!-- Live Stat Counters -->
        <div class="flex space-x-4 items-center">
            <div class="px-3 py-1.5 bg-yellow-500/15 border border-yellow-500/30 rounded-xl flex items-center space-x-1.5">
                <span class="text-yellow-400 font-bold">🪙</span>
                <span id="django-coin-counter" class="font-mono text-yellow-300 font-semibold">{{ user.profile.coins }}</span>
            </div>
            <div class="px-3 py-1.5 bg-emerald-500/15 border border-emerald-500/30 rounded-xl flex items-center space-x-1.5">
                <span class="text-emerald-400 font-bold">💵</span>
                <span id="django-cash-counter" class="font-mono text-emerald-300 font-semibold">$ {{ user.profile.wallet_balance }}</span>
            </div>
        </div>
    </div>

    <!-- Active component root containing Django data models -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <!-- Reusable HTML Card for DJANGO templates -->
        <div class="glass-card md:col-span-2 p-6 rounded-2xl border border-white/5 bg-slate-900/60 shadow-xl relative overflow-hidden">
            <div class="absolute -top-12 -right-12 w-24 h-24 bg-purple-600/10 rounded-full blur-2xl"></div>
            <h3 class="text-xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent">
                ${selectedModule.toUpperCase()} CONSOLE
            </h3>
            <p class="text-slate-400 text-sm mt-1">This UI binds with Django template handles natively. Dynamic variables are rendered via Jinja placeholders.</p>
            
            <div class="mt-4 border-t border-white/10 pt-4">
                <label class="text-xs text-slate-400 block mb-2">AJAX Bind Target: /api/{{ selectedModule }}/</label>
                <div id="dynamic-${selectedModule}-root" class="bg-black/40 rounded-xl p-4 border border-white/5">
                    <!-- Jinja tags -->
                    <p class="text-sm font-semibold">User XP Level: <span class="text-purple-400">{{ user.profile.xp }} XP</span></p>
                    <div class="w-full bg-slate-800 h-2.5 rounded-full mt-2 overflow-hidden">
                        <div class="bg-gradient-to-r from-purple-500 to-cyan-400 h-full" style="width: {% widthratio user.profile.xp user.profile.level|add:100 100 %}%"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
{% endblock %}
`;
    }

    if (activeTab === "ajax") {
      return `/**
 * CSRF-Safe Django AJAX requests helper
 * Place this in your global gaming JavaScript bundle (main.js)
 */

function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

const csrftoken = getCookie('csrftoken');

// Universal AJAX wrapper for RewardVerse Modules
async function sendRewardVerseRequest(endpoint, payload = {}) {
    const spinner = document.getElementById('gaming-global-spinner');
    if (spinner) spinner.classList.remove('hidden');

    try {
        const response = await fetch(endpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': csrftoken,
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            throw new Error(\`HTTP error! status: \${response.status}\`);
        }

        const data = await response.json();
        
        // Handle global HUD counter updates automatically
        if (data.user_coins !== undefined) {
            animateCounter('user-coins-hud', data.user_coins);
        }
        if (data.user_balance !== undefined) {
            animateMoneyCounter('user-cash-hud', data.user_balance);
        }
        if (data.level_up) {
            triggerLevelUpCelebration(data.new_level);
        }

        return data;
    } catch (error) {
        console.error('RewardVerse Sync Failure:', error);
        triggerToastNotification('Sync Failed: Check fraud checker alerts.', 'error');
        return null;
    } finally {
        if (spinner) spinner.classList.add('hidden');
    }
}

function animateCounter(elementId, targetValue) {
    const el = document.getElementById(elementId);
    if (!el) return;
    const startValue = parseInt(el.innerText) || 0;
    const duration = 800;
    const startTime = performance.now();

    function updateCounter(currentTime) {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        const ease = 1 - Math.pow(1 - progress, 3); // cubic easeOut
        const currentValue = Math.floor(startValue + (targetValue - startValue) * ease);
        el.innerText = currentValue;
        if (progress < 1) {
            requestAnimationFrame(updateCounter);
        } else {
            el.innerText = targetValue;
        }
    }
    requestAnimationFrame(updateCounter);
}
`;
    }

    return "";
  };

  return (
    <div className="glass-panel text-gray-200 border border-neon-purple/30 glow-purple overflow-hidden flex flex-col h-full max-h-[85vh]">
      {/* Inspector Header */}
      <div className="bg-slate-950/90 py-4 px-5 border-b border-white/10 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Terminal className="text-neon-purple w-5 h-5 animate-pulse" />
          <div>
            <h3 className="font-bold tracking-tight text-white flex items-center gap-1.5 font-mono text-sm">
              <span className="text-neon-cyan">[Django]</span> RewardVerse Pipeline SDK
            </h3>
            <p className="text-[10px] text-gray-400 font-mono">
              Ready for backend setup & model injection
            </p>
          </div>
        </div>
        {onClose && (
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white bg-white/5 hover:bg-white/10 px-2 py-1 rounded text-xs font-mono transition-colors"
          >
            DISMISS
          </button>
        )}
      </div>

      {/* Control Rails */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-2 bg-slate-900/80 p-3 border-b border-white/5">
        <div className="col-span-1 flex items-center space-x-1.5">
          <Cpu className="w-4 h-4 text-neon-cyan" />
          <span className="text-[11px] font-bold uppercase font-mono tracking-wide text-gray-300">
            Active Module:
          </span>
          <select
            value={selectedModule}
            onChange={(e) => setSelectedModule(e.target.value)}
            className="bg-black/60 border border-white/10 text-neon-cyan text-xs font-mono rounded px-2 py-1 flex-1 focus:outline-none focus:border-neon-cyan"
          >
            {modules.map((m) => (
              <option key={m.id} value={m.id}>
                {m.name}
              </option>
            ))}
          </select>
        </div>

        {/* Tab Switcher */}
        <div className="col-span-2 flex space-x-1 justify-end">
          <button
            onClick={() => setActiveTab("models")}
            className={`px-3 py-1 rounded text-xs font-mono transition-all flex items-center space-x-1 ${
              activeTab === "models"
                ? "bg-neon-purple text-white shadow-sm font-semibold"
                : "bg-white/5 text-gray-400 hover:text-white hover:bg-white/10"
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>models.py</span>
          </button>
          <button
            onClick={() => setActiveTab("views")}
            className={`px-3 py-1 rounded text-xs font-mono transition-all flex items-center space-x-1 ${
              activeTab === "views"
                ? "bg-neon-purple text-white shadow-sm font-semibold"
                : "bg-white/5 text-gray-400 hover:text-white hover:bg-white/10"
            }`}
          >
            <Code className="w-3.5 h-3.5" />
            <span>views.py</span>
          </button>
          <button
            onClick={() => setActiveTab("templates")}
            className={`px-3 py-1 rounded text-xs font-mono transition-all flex items-center space-x-1 ${
              activeTab === "templates"
                ? "bg-neon-purple text-white shadow-sm font-semibold"
                : "bg-white/5 text-gray-400 hover:text-white hover:bg-white/10"
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>templates/</span>
          </button>
          <button
            onClick={() => setActiveTab("ajax")}
            className={`px-3 py-1 rounded text-xs font-mono transition-all flex items-center space-x-1 ${
              activeTab === "ajax"
                ? "bg-neon-purple text-white shadow-sm font-semibold"
                : "bg-white/5 text-gray-400 hover:text-white hover:bg-white/10"
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>ajax.js</span>
          </button>
        </div>
      </div>

      {/* Code Area */}
      <div className="p-4 flex-1 bg-black/60 relative overflow-y-auto block min-h-[250px] font-mono select-all">
        {/* Copy Button */}
        <button
          onClick={() => triggerCopy(getCodeContent())}
          className="absolute top-4 right-4 bg-white/5 hover:bg-white/10 border border-white/10 p-2 rounded-lg text-gray-400 hover:text-white transition-all flex items-center space-x-1"
          title="Copy to Clipboard"
        >
          {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4" />}
          <span className="text-[10px] hidden sm:inline">{copied ? "Copied" : "Copy"}</span>
        </button>

        <pre className="text-xs text-green-400 whitespace-pre leading-relaxed font-mono">
          <code>{getCodeContent()}</code>
        </pre>
      </div>

      {/* Footer Info */}
      <div className="bg-slate-950/80 px-4 py-3 border-t border-white/10 text-[11px] text-gray-400 font-mono text-center flex sm:justify-between flex-wrap items-center">
        <span>🤖 RewardVerse is fully optimized for standard Django applications.</span>
        <span className="text-neon-purple font-semibold hover:underline cursor-pointer">
          Read Django-Template integrations guide &rarr;
        </span>
      </div>
    </div>
  );
}
