import React, { useState } from "react";
import { UserProfile, LeaderboardUser } from "../types";
import { Trophy, Award, Search, TrendingUp, Sparkles, User, Medal } from "lucide-react";

interface LeaderboardModuleProps {
  user: UserProfile;
}

const GLOBAL_LEADERS: LeaderboardUser[] = [
  { rank: 1, username: "VaporShogun", avatar: "https://images.unsplash.com/photo-1566492031773-4f4e44671857?q=80&w=250&auto=format&fit=crop", xp: 14200, level: 42, coins: 5900 },
  { rank: 2, username: "SekaGamer", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=250&auto=format&fit=crop", xp: 12100, level: 38, coins: 4100 },
  { rank: 3, username: "ApexNova", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=250&auto=format&fit=crop", xp: 9800, level: 31, coins: 3500 },
  { rank: 4, username: "ZeroCool", avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=250&auto=format&fit=crop", xp: 8700, level: 27, coins: 3100 },
  { rank: 5, username: "GamerZero (You)", avatar: "https://images.unsplash.com/photo-1628157582853-a796fa650a6a?q=80&w=250&auto=format&fit=crop", xp: 2450, level: 8, coins: 1450, isCurrentUser: true },
  { rank: 6, username: "SynthKnight", avatar: "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?q=80&w=250&auto=format&fit=crop", xp: 2300, level: 7, coins: 1200 },
  { rank: 7, username: "HexGlitch", avatar: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?q=80&w=250&auto=format&fit=crop", xp: 1980, level: 6, coins: 900 }
];

const WEEKLY_LEADERS: LeaderboardUser[] = [
  { rank: 1, username: "SekaGamer", avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=250&auto=format&fit=crop", xp: 3400, level: 38, coins: 1200 },
  { rank: 2, username: "VaporShogun", avatar: "https://images.unsplash.com/photo-1566492031773-4f4e44671857?q=80&w=250&auto=format&fit=crop", xp: 3100, level: 42, coins: 900 },
  { rank: 3, username: "GamerZero (You)", avatar: "https://images.unsplash.com/photo-1628157582853-a796fa650a6a?q=80&w=250&auto=format&fit=crop", xp: 2450, level: 8, coins: 1450, isCurrentUser: true },
  { rank: 4, username: "ApexNova", avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=250&auto=format&fit=crop", xp: 2100, level: 31, coins: 800 },
  { rank: 5, username: "HexGlitch", avatar: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?q=80&w=250&auto=format&fit=crop", xp: 1100, level: 6, coins: 500 }
];

export default function LeaderboardModule({ user }: LeaderboardModuleProps) {
  const [toggleMode, setToggleMode] = useState<"global" | "weekly">("global");

  const activeLeaders = toggleMode === "global" ? GLOBAL_LEADERS : WEEKLY_LEADERS;

  // Build podium sorting elements
  const podium = activeLeaders.slice(0, 3);
  const reorderPodium = [podium[1], podium[0], podium[2]].filter(Boolean); // Place 1st place in industrial middle, 2nd on left, 3rd on right

  // Map user dynamic traits if matching
  const renderRowLeaders = activeLeaders.map((u) => {
    if (u.isCurrentUser) {
      return {
        ...u,
        username: `${user.username} (You)`,
        avatar: user.avatar,
        xp: user.xp + (user.level - 1) * 100, // Accumulated estimate
        level: user.level,
        coins: user.coins
      };
    }
    return u;
  });

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 select-none pb-20">
      {/* Route Header Badge */}
      <div className="lg:col-span-12 glass-panel p-4 flex justify-between items-center border border-neon-blue/20 animate-fade-in">
        <div className="flex items-center space-x-3">
          <Trophy className="text-neon-gold w-5 h-5 animate-pulse" />
          <div>
            <span className="text-xs font-mono text-neon-gold block">DJANGO PLATFORM ROUTE:</span>
            <span className="text-sm font-bold text-white font-mono tracking-wide">/ui/leaderboard/ [Rankings Matrix]</span>
          </div>
        </div>

        {/* Dynamic Weekly Toggle */}
        <div className="flex bg-black/60 p-1 rounded-xl border border-white/5 font-mono text-xs">
          <button
            onClick={() => setToggleMode("global")}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              toggleMode === "global"
                ? "bg-neon-gold text-slate-950 font-bold"
                : "text-gray-400 hover:text-white"
            }`}
          >
            All-Time Global
          </button>
          <button
            onClick={() => setToggleMode("weekly")}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              toggleMode === "weekly"
                ? "bg-neon-gold text-slate-950 font-bold"
                : "text-gray-400 hover:text-white"
            }`}
          >
            Weekly Sprint
          </button>
        </div>
      </div>

      {/* Podium Block (First 3 slots) */}
      <div className="lg:col-span-12 flex flex-col items-center justify-center py-6 sm:py-8">
        <div className="flex items-end justify-center space-x-3 sm:space-x-8 max-w-xl w-full">
          {/* Rank 2 (Left Position) */}
          {reorderPodium[0] && (
            <div className="flex flex-col items-center w-28 sm:w-36 transition-transform duration-500 hover:scale-105">
              <div className="relative mb-3">
                <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-slate-500 p-[2.5px] shadow-lg">
                  <img
                    src={reorderPodium[0].username.includes("You") ? user.avatar : reorderPodium[0].avatar}
                    alt="Silver place"
                    className="w-full h-full object-cover rounded-full"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <span className="absolute -top-3 left-1/2 transform -translate-x-1/2 text-lg">🥈</span>
                <span className="absolute -bottom-1 -right-1 bg-slate-500 text-slate-950 font-bold px-1.5 py-0.5 rounded-full text-[9px] font-mono">
                  #2
                </span>
              </div>
              <span className="text-xs sm:text-sm font-bold text-gray-300 truncate w-24 text-center">
                {reorderPodium[0].username.includes("You") ? user.username : reorderPodium[0].username}
              </span>
              <span className="text-[10px] text-gray-400 font-mono mt-0.5">
                {reorderPodium[0].xp.toLocaleString()} XP
              </span>
              {/* Silver Pillar Column */}
              <div className="w-full h-16 sm:h-20 bg-gradient-to-t from-slate-950 via-slate-800 to-slate-700/60 rounded-t-2xl border-t-2 border-slate-500 mt-4 shadow flex flex-col items-center justify-center">
                <Medal className="w-5 h-5 text-gray-400 animate-pulse" />
              </div>
            </div>
          )}

          {/* Rank 1 (Middle Position - Highest) */}
          {reorderPodium[1] && (
            <div className="flex flex-col items-center w-32 sm:w-40 transition-transform duration-500 hover:scale-110">
              <div className="relative mb-3">
                <div className="w-18 h-18 sm:w-20 sm:h-20 rounded-full bg-neon-gold p-[3px] shadow-xl glow-gold">
                  <img
                    src={reorderPodium[1].username.includes("You") ? user.avatar : reorderPodium[1].avatar}
                    alt="Gold Champion"
                    className="w-full h-full object-cover rounded-full"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <span className="absolute -top-4 left-1/2 transform -translate-x-1/2 text-2xl animate-bounce">👑</span>
                <span className="absolute -bottom-1 -right-1 bg-[#fbbf24] text-slate-950 font-extrabold px-1.5 py-0.5 rounded-full text-[10px] font-mono border border-slate-950">
                  #1
                </span>
              </div>
              <span className="text-sm sm:text-base font-extrabold text-[#fbbf24] tracking-tight truncate w-28 text-center text-glow-gold">
                {reorderPodium[1].username.includes("You") ? user.username : reorderPodium[1].username}
              </span>
              <span className="text-xs text-yellow-300 font-mono font-bold mt-0.5">
                {reorderPodium[1].xp.toLocaleString()} XP
              </span>
              {/* Gold Pillar Column */}
              <div className="w-full h-24 sm:h-28 bg-gradient-to-t from-slate-950 via-amber-950/40 to-amber-700/60 rounded-t-2xl border-t-4 border-neon-gold mt-4 shadow-xl flex flex-col items-center justify-center">
                <Trophy className="w-6 h-6 text-neon-gold animate-bounce" />
              </div>
            </div>
          )}

          {/* Rank 3 (Right Position) */}
          {reorderPodium[2] && (
            <div className="flex flex-col items-center w-28 sm:w-36 transition-transform duration-500 hover:scale-105">
              <div className="relative mb-3">
                <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-amber-700 p-[2px] shadow-lg">
                  <img
                    src={reorderPodium[2].username.includes("You") ? user.avatar : reorderPodium[2].avatar}
                    alt="Bronze place"
                    className="w-full h-full object-cover rounded-full"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <span className="absolute -top-3 left-1/2 transform -translate-x-1/2 text-lg">🥉</span>
                <span className="absolute -bottom-1 -right-1 bg-amber-700 text-slate-950 font-bold px-1.5 py-0.5 rounded-full text-[9px] font-mono">
                  #3
                </span>
              </div>
              <span className="text-xs sm:text-sm font-bold text-gray-300 truncate w-24 text-center">
                {reorderPodium[2].username.includes("You") ? user.username : reorderPodium[2].username}
              </span>
              <span className="text-[10px] text-gray-400 font-mono mt-0.5">
                {reorderPodium[2].xp.toLocaleString()} XP
              </span>
              {/* Bronze Pillar Column */}
              <div className="w-full h-12 sm:h-16 bg-gradient-to-t from-slate-950 via-slate-800 to-amber-900/60 rounded-t-2xl border-t-2 border-amber-700 mt-4 shadow flex flex-col items-center justify-center">
                <Medal className="w-5 h-5 text-amber-600 animate-pulse" />
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Ledger Rankings Table Panel (Right bottom rows grid) */}
      <div className="col-span-1 lg:col-span-12 space-y-4">
        <div className="glass-panel p-5 border border-white/5 bg-slate-900/40">
          <h3 className="font-bold text-sm uppercase text-white font-mono tracking-wide mb-4">
            Leaderboard Ranks Table
          </h3>

          <div className="space-y-2 mt-4">
            {renderRowLeaders.map((leader, i) => {
              const isMe = leader.isCurrentUser;
              return (
                <div
                  key={i}
                  className={`p-3.5 rounded-xl border flex justify-between items-center transition-all ${
                    isMe
                      ? "border-neon-gold bg-neon-gold/15 shadow glow-purple animate-pulse"
                      : "border-white/5 bg-black/45 hover:bg-black/60"
                  }`}
                >
                  <div className="flex items-center space-x-4">
                    {/* Rank Indicator */}
                    <span
                      className={`w-7 text-center font-mono text-sm font-bold ${
                        leader.rank === 1
                          ? "text-neon-gold text-base"
                          : leader.rank === 2
                          ? "text-slate-300"
                          : leader.rank === 3
                          ? "text-amber-500"
                          : "text-gray-500"
                      }`}
                    >
                      {leader.rank === 1 ? "🥇" : leader.rank === 2 ? "🥈" : leader.rank === 3 ? "🥉" : `#${leader.rank}`}
                    </span>

                    {/* Avatar Name */}
                    <div className="flex items-center space-x-3">
                      <img
                        src={leader.avatar}
                        alt="Rank image"
                        className="w-10 h-10 rounded-full border border-white/10 object-cover"
                        referrerPolicy="no-referrer"
                      />
                      <div>
                        <span className="font-bold text-xs sm:text-sm text-white block">
                          {leader.username}
                        </span>
                        <span className="text-[10px] text-gray-400 font-mono block">
                          Level {leader.level}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="text-right font-mono text-xs">
                    <span className="font-extrabold text-neon-cyan block">
                      {leader.xp.toLocaleString()} XP
                    </span>
                    <span className="text-[10px] text-neon-gold mt-0.5 block">
                      🪙 {leader.coins}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
