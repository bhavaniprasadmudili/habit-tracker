import React, { useState } from "react";
import { UserProfile, WalletTransaction, AppNotification } from "../types";
import { ShieldAlert, ShieldCheck, Fingerprint, Network, Terminal, RefreshCw, Cpu, Star } from "lucide-react";

interface FraudModuleProps {
  user: UserProfile;
  onUpdateUser: (newUser: UserProfile) => void;
  onTriggerToast: (msg: string, type: "success" | "info" | "error") => void;
  onAddNotification: (notif: AppNotification) => void;
}

export default function FraudModule({
  user,
  onUpdateUser,
  onTriggerToast,
  onAddNotification
}: FraudModuleProps) {
  const [recomputing, setRecomputing] = useState<boolean>(false);

  const handleAuditRecompute = () => {
    if (recomputing) return;
    setRecomputing(true);

    onTriggerToast("Auditing browser hardware context & Django sessions...", "info");

    setTimeout(() => {
      setRecomputing(false);

      // Restore health score as user re-runs security scans
      onUpdateUser({
        ...user,
        securityScore: 100,
        deviceCheckOk: true,
        isVerified: true
      });

      const auditNotification: AppNotification = {
        id: `SEC-${Math.floor(100000 + Math.random() * 900000)}`,
        title: "Security Shield Restored",
        description: "Your session and device fingerprint validated clean. Security Score re-established to 100%.",
        timestamp: new Date().toLocaleTimeString(),
        read: false,
        type: "security"
      };

      onAddNotification(auditNotification);
      onTriggerToast("Security score reset! Interactive token refreshed.", "success");
    }, 2000);
  };

  const securityChecks = [
    { title: "Browser Automation Driver", desc: "No Selenium, Puppeteer, or headless triggers", status: "CLEAN", icon: Cpu, ok: true },
    { title: "IP Redundancy Counter", desc: "No secondary reward accounts mapped to standard IP", status: "CLEAN", icon: Network, ok: true },
    { title: "Escrow Fingerprint Match", desc: "Hardware UUID matches Django session ID", status: "VERIFIED", icon: Fingerprint, ok: user.deviceCheckOk },
    { title: "Ad Impress Integrity", desc: "User is actively rendering vector adframes", status: "AUDITED", icon: Terminal, ok: user.isVerified }
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 select-none pb-20">
      {/* Route Header Badge */}
      <div className="lg:col-span-12 glass-panel p-4 flex justify-between items-center border border-neon-blue/20">
        <div className="flex items-center space-x-3">
          <ShieldAlert className="text-neon-pink w-5 h-5 animate-pulse" />
          <div>
            <span className="text-xs font-mono text-neon-pink block">DJANGO PLATFORM ROUTE:</span>
            <span className="text-sm font-bold text-white font-mono tracking-wide">/ui/fraud/ [Integrity Audit]</span>
          </div>
        </div>
        <div className="flex items-center space-x-2 text-xs font-mono">
          <span className="text-gray-400">Score Check:</span>
          <span className={`${user.securityScore >= 80 ? "text-green-400" : "text-neon-pink"} font-bold`}>
            {user.securityScore}% Index
          </span>
        </div>
      </div>

      {/* Account integrity indicators dial (Left side) */}
      <div className="col-span-1 lg:col-span-4 space-y-6">
        <div className="glass-panel p-6 border border-white/5 bg-slate-900/40 text-center flex flex-col items-center">
          <h3 className="font-bold text-sm uppercase text-gray-300 tracking-wider mb-6 font-mono self-start flex items-center gap-1.5">
            <Fingerprint className="w-4 h-4 text-neon-pink" /> SECURITY CORE INDEX
          </h3>

          {/* Semicircle styled radial meter representation */}
          <div className="relative w-36 h-36 flex items-center justify-center mb-4">
            {/* Outer neon pulsing ring */}
            <div className={`absolute inset-0 rounded-full border-4 transition-colors ${
              user.securityScore >= 80
                ? "border-green-500/20 glow-cyan"
                : "border-neon-pink/20"
            }`}></div>

            <div className="text-center font-mono">
              <span className={`text-4xl font-extrabold block ${
                user.securityScore >= 80 ? "text-green-400" : "text-neon-pink"
              }`}>
                {user.securityScore}%
              </span>
              <span className="text-[9px] text-gray-400 uppercase tracking-widest font-bold mt-1 block">
                {user.securityScore >= 80 ? "TRUSTED" : "FLAGGED UNVERIFIED"}
              </span>
            </div>
          </div>

          <p className="text-xs text-gray-400 leading-relaxed font-mono px-2">
            Accounts with scores below 60 have direct financial cashouts temporarily locked.
          </p>

          <button
            onClick={handleAuditRecompute}
            disabled={recomputing}
            className="w-full mt-6 py-2.5 bg-white/5 hover:bg-white/10 active:scale-95 text-xs text-neon-cyan border border-neon-cyan/30 rounded-xl font-mono uppercase font-bold tracking-wider flex justify-center items-center gap-1.5 transition-all"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${recomputing ? "animate-spin" : ""}`} />
            <span>{recomputing ? "AUDITING..." : "RECOMPUTE AUDIT SCANS"}</span>
          </button>
        </div>

        {/* Anti-cheat badges display */}
        <div className="glass-panel p-6 border border-white/5 bg-slate-900/40">
          <h3 className="font-bold text-sm uppercase text-gray-300 tracking-wider mb-4 font-mono">
            Anti-Cheat hardware badges
          </h3>

          <div className="space-y-3 font-mono text-xs">
            <div className="p-3 bg-black/45 rounded-xl border border-white/5 flex items-center space-x-3">
              <span className="text-lg">🛡️</span>
              <div>
                <span className="font-bold text-white block">Device Fingerprinted</span>
                <span className="text-[10px] text-gray-400 block">UUID binds matching verified profiles</span>
              </div>
            </div>

            <div className="p-3 bg-black/45 rounded-xl border border-white/5 flex items-center space-x-3">
              <span className="text-lg">📱</span>
              <div>
                <span className="font-bold text-white block">Clean emulator record</span>
                <span className="text-[10px] text-gray-400 block">Hardware matches native cellular chips</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Account Verification list checks (Right side) */}
      <div className="col-span-1 lg:col-span-8 space-y-4">
        <div className="glass-panel p-6 border border-white/5 bg-slate-900/40">
          <h3 className="font-bold text-base text-white tracking-tight font-mono mb-4">
            Security audit checks logs
          </h3>

          <div className="space-y-3 mt-4">
            {securityChecks.map((check, i) => {
              const Icon = check.icon;
              return (
                <div
                  key={i}
                  className="p-4 bg-black/45 rounded-xl border border-white/5 flex justify-between items-center transition-all font-mono text-xs"
                >
                  <div className="flex items-start space-x-3.5 max-w-[70%]">
                    <div className="p-2 bg-slate-950 rounded-lg text-neon-cyan mt-0.5">
                      <Icon className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-bold text-white tracking-tight text-xs sm:text-sm">
                        {check.title}
                      </h4>
                      <p className="text-[10px] sm:text-xs text-gray-500 mt-0.5">
                        {check.desc}
                      </p>
                    </div>
                  </div>

                  <div className="text-right flex-shrink-0">
                    <span className={`px-2.5 py-1 text-[10px] font-bold rounded-lg ${
                      check.ok
                        ? "bg-green-500/10 text-green-400 border border-green-500/20"
                        : "bg-neon-pink/10 text-neon-pink border border-neon-pink/20"
                    }`}>
                      {check.ok ? check.status : "ALERT FLAG"}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
