import React, { useState, useEffect } from "react";
import { UserProfile, WalletTransaction } from "../types";
import { Gamepad2, AlertCircle, RefreshCw, Key, ShieldCheck, Star, HelpCircle, Trophy } from "lucide-react";

interface GuessModuleProps {
  user: UserProfile;
  onUpdateUser: (newUser: UserProfile) => void;
  onAddTransaction: (tx: WalletTransaction) => void;
  onTriggerToast: (msg: string, type: "success" | "info" | "error") => void;
}

type GuessMode = "number" | "word";

export default function GuessModule({
  user,
  onUpdateUser,
  onAddTransaction,
  onTriggerToast
}: GuessModuleProps) {
  const [activeMode, setActiveMode] = useState<GuessMode>("number");

  // --- NUMBER GAME STATES ---
  const [secretNumber, setSecretNumber] = useState<number>(0);
  const [numAttempts, setNumAttempts] = useState<number>(0);
  const [maxNumAttempts] = useState<number>(4);
  const [numberGuess, setNumberGuess] = useState<string>("");
  const [numFeedback, setNumFeedback] = useState<string>("Initiate scan...");
  const [numWon, setNumWon] = useState<boolean | null>(null); // null, true, false
  const [numMultiplier, setNumMultiplier] = useState<number>(5.0);

  // --- CIPHER GAME STATES ---
  const wordsPool = [
    { word: "DJANGO", scrambled: "JOGDNA", hint: "High-productivity Python web framework." },
    { word: "CELERY", scrambled: "YECLER", hint: "Distributed asynchronous tasks organizer." },
    { word: "ORM", scrambled: "MRU", hint: "Object Relational Mapping model query tool." },
    { word: "POSTGRES", scrambled: "SRTGPOES", hint: "Most compliant open-source SQL database." }
  ];
  const [activeCipherIdx, setActiveCipherIdx] = useState<number>(0);
  const [scrambledWord, setScrambledWord] = useState<string>("");
  const [cipherInput, setCipherInput] = useState<string>("");
  const [wordFeedback, setWordFeedback] = useState<string>("Awaiting input...");
  const [wordAttempts, setWordAttempts] = useState<number>(0);
  const [maxWordAttempts] = useState<number>(3);
  const [wordWon, setWordWon] = useState<boolean | null>(null);

  // Initialize States
  useEffect(() => {
    resetNumberGame();
    resetWordGame(0);
  }, []);

  const resetNumberGame = () => {
    setSecretNumber(Math.floor(Math.random() * 25) + 1);
    setNumAttempts(0);
    setNumberGuess("");
    setNumFeedback("Signal pulse acquired. Enter scanning number 1 to 25.");
    setNumWon(null);
    setNumMultiplier(5.0);
  };

  const resetWordGame = (idx: number) => {
    const val = wordsPool[idx % wordsPool.length];
    setScrambledWord(val.scrambled);
    setCipherInput("");
    setWordFeedback("Cipher integrity scrambler active.");
    setWordAttempts(0);
    setWordWon(null);
    setActiveCipherIdx(idx % wordsPool.length);
  };

  // Process Number Guess
  const handleNumberSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (numWon !== null) return;

    const guessInt = parseInt(numberGuess);
    if (isNaN(guessInt) || guessInt < 1 || guessInt > 25) {
      onTriggerToast("Vibe signal out of core (1-25) thresholds!", "error");
      return;
    }

    const nextAttempts = numAttempts + 1;
    setNumAttempts(nextAttempts);

    if (guessInt === secretNumber) {
      setNumWon(true);
      setNumFeedback(`DECRYPT MATCHED! Number was ${secretNumber}!`);
      // Pay rewards
      const coinPayout = Math.floor(100 * numMultiplier);
      const xpPayout = Math.floor(60 * numMultiplier);
      onUpdateUser({
        ...user,
        coins: user.coins + coinPayout,
        xp: user.xp + xpPayout
      });

      const newTx: WalletTransaction = {
        id: `GW-${Math.floor(100000 + Math.random() * 900000)}`,
        type: "earn",
        amount: coinPayout,
        currency: "coins",
        description: `Won Matrix Guess Game (${numMultiplier}x multiplier)`,
        timestamp: new Date().toISOString().replace("T", " ").substring(0, 19),
        status: "completed"
      };
      onAddTransaction(newTx);
      onTriggerToast(`MATRIX DECRYPTED! +🪙${coinPayout} coins and +${xpPayout} XP!`, "success");
    } else {
      // Lower multiplier
      const nextMulti = Math.max(1.0, numMultiplier - 1.0);
      setNumMultiplier(nextMulti);

      if (guessInt < secretNumber) {
        setNumFeedback(`SIGNAL LOW! Vibe target is HIGHER than ${guessInt}.`);
      } else {
        setNumFeedback(`SIGNAL HEAD! Vibe target is LOWER than ${guessInt}.`);
      }

      if (nextAttempts >= maxNumAttempts) {
        setNumWon(false);
        setNumFeedback(`SCRA ENTRANCE LOCKED! Target code was: ${secretNumber}`);
        onTriggerToast("Matrix decryption attempts expired!", "error");
      }
    }
  };

  // Process Word Decipient
  const handleWordSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (wordWon !== null) return;

    const sanitizedInput = cipherInput.trim().toUpperCase();
    if (!sanitizedInput) return;

    const nextAttempts = wordAttempts + 1;
    setWordAttempts(nextAttempts);

    const actualTarget = wordsPool[activeCipherIdx].word;

    if (sanitizedInput === actualTarget) {
      setWordWon(true);
      setWordFeedback(`CIPHER BREAK SUCCESSFUL! Word is ${actualTarget}.`);

      const coinPayout = 150;
      const xpPayout = 80;
      onUpdateUser({
        ...user,
        coins: user.coins + coinPayout,
        xp: user.xp + xpPayout
      });

      const newTx: WalletTransaction = {
        id: `GW-${Math.floor(100000 + Math.random() * 900000)}`,
        type: "earn",
        amount: coinPayout,
        currency: "coins",
        description: `Unscrambled word "${actualTarget}"`,
        timestamp: new Date().toISOString().replace("T", " ").substring(0, 19),
        status: "completed"
      };
      onAddTransaction(newTx);
      onTriggerToast(`HACK COMPLETE! Word unscrambled! +🪙${coinPayout} and +${xpPayout} XP!`, "success");
    } else {
      setWordFeedback("MISTAKE! Scrambler feedback mismatch.");
      if (nextAttempts >= maxWordAttempts) {
        setWordWon(false);
        setWordFeedback(`LOCKOUT! Core code word was: ${actualTarget}`);
        onTriggerToast("Word matching failed! System locked.", "error");
      }
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 select-none pb-20">
      {/* Platform Header */}
      <div className="lg:col-span-12 glass-panel p-4 flex justify-between items-center border border-neon-blue/20">
        <div className="flex items-center space-x-3">
          <Gamepad2 className="text-neon-cyan w-5 h-5 animate-pulse" />
          <div>
            <span className="text-xs font-mono text-neon-cyan block">DJANGO PLATFORM ROUTE:</span>
            <span className="text-sm font-bold text-white font-mono tracking-wide">/ui/guess/ [Decryption Core]</span>
          </div>
        </div>
        
        {/* Toggle Game Selectors */}
        <div className="flex space-x-1">
          <button
            onClick={() => setActiveMode("number")}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-all ${
              activeMode === "number"
                ? "bg-neon-cyan text-slate-950 font-bold shadow glow-cyan"
                : "bg-white/5 text-gray-400 hover:text-white"
            }`}
          >
            Number Matrix
          </button>
          <button
            onClick={() => setActiveMode("word")}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-all ${
              activeMode === "word"
                ? "bg-neon-purple text-white font-bold shadow glow-purple"
                : "bg-white/5 text-gray-400 hover:text-white"
            }`}
          >
            Cipher Unscramble
          </button>
        </div>
      </div>

      {activeMode === "number" ? (
        /* --- Number Game View --- */
        <div className="col-span-1 lg:col-span-8 glass-panel p-6 sm:p-8 border border-white/5 bg-slate-900/40 relative">
          <div className="absolute top-0 right-0 w-32 h-32 bg-neon-cyan/5 rounded-full blur-2xl"></div>

          <div className="flex justify-between items-center mb-6">
            <h3 className="font-bold text-base text-white font-mono tracking-wide flex items-center gap-1.5">
              <Star className="w-5 h-5 text-neon-cyan animate-spin" /> CORE SCANNERS
            </h3>
            {/* Multiplier Bubble */}
            <div className="px-3 py-1.5 bg-neon-cyan/15 border border-neon-cyan/35 text-neon-cyan font-mono text-xs font-bold rounded-lg uppercase tracking-wider">
              Multiplier: {numMultiplier.toFixed(1)}x
            </div>
          </div>

          <p className="text-xs text-gray-300 leading-relaxed max-w-xl mb-6">Object: Identify a quantum coefficient between 1 and 25. Incorrect attempts degrade scanner multipliers.</p>

          <form onSubmit={handleNumberSubmit} className="space-y-6">
            {/* Input & attempts logs */}
            <div className="flex items-center space-x-4">
              <input
                type="number"
                min="1"
                max="25"
                value={numberGuess}
                onChange={(e) => setNumberGuess(e.target.value)}
                disabled={numWon !== null}
                className="p-3 bg-black/60 border border-white/10 rounded-xl font-mono text-neon-cyan text-lg w-28 text-center focus:outline-none focus:border-neon-cyan"
                placeholder="?"
              />
              <button
                type="submit"
                disabled={numWon !== null}
                className={`py-3.5 px-6 rounded-xl font-mono font-bold uppercase text-xs tracking-wider transition-all flex-1 ${
                  numWon !== null
                    ? "bg-white/5 border border-white/5 text-gray-500 cursor-not-allowed"
                    : "bg-neon-cyan glow-cyan text-slate-950 hover:bg-neon-cyan/95 text-center"
                }`}
              >
                Scan Matrix Signal
              </button>
            </div>

            {/* Attempts Indicator Bar */}
            <div className="font-mono text-xs space-y-2">
              <div className="flex justify-between text-[11px] text-gray-400">
                <span>Scanner Depletion Index:</span>
                <span>{numAttempts} / {maxNumAttempts} Attempts Used</span>
              </div>
              <div className="flex space-x-1.5">
                {Array.from({ length: maxNumAttempts }).map((_, i) => (
                  <div
                    key={i}
                    className={`h-2.5 flex-1 rounded-full border transition-all ${
                      i < numAttempts
                        ? "bg-neon-pink border-neon-pink glow-cyan"
                        : "bg-black/40 border-white/5"
                    }`}
                  ></div>
                ))}
              </div>
            </div>

            {/* Feed back panel */}
            <div className={`p-4 rounded-xl border text-center font-mono text-xs ${
              numWon === true
                ? "bg-green-500/15 border-green-500/25 text-green-400"
                : numWon === false
                ? "bg-neon-pink/15 border-neon-pink/25 text-neon-pink"
                : "bg-black/35 border-white/5 text-[#fbbf24] mt-4"
            }`}>
              {numFeedback}
            </div>

            {numWon !== null && (
              <div className="flex justify-center mt-6">
                <button
                  type="button"
                  onClick={resetNumberGame}
                  className="px-5 py-3 bg-[#a855f7] hover:bg-neon-purple text-xs font-mono font-bold uppercase tracking-wide text-white rounded-xl flex items-center space-x-1.5"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>Calibrate Scanner</span>
                </button>
              </div>
            )}
          </form>
        </div>
      ) : (
        /* --- Word Unscramble View --- */
        <div className="col-span-1 lg:col-span-8 glass-panel p-6 sm:p-8 border border-white/5 bg-slate-900/40 relative">
          <div className="absolute top-0 right-0 w-32 h-32 bg-neon-purple/5 rounded-full blur-2xl"></div>

          <div className="flex justify-between items-center mb-6">
            <h3 className="font-bold text-base text-white font-mono tracking-wide flex items-center gap-1.5">
              <Key className="w-5 h-5 text-neon-purple animate-pulse" /> CIPHER DECRYPTION
            </h3>
            <div className="px-3 py-1.5 bg-neon-purple/15 border border-neon-purple/35 text-neon-purple font-mono text-xs font-bold rounded-lg uppercase tracking-wider">
              Earn: 🪙 150 Base
            </div>
          </div>

          <div className="bg-black/40 p-6 rounded-2xl border border-white/5 flex flex-col items-center justify-center mb-6 select-text">
            <span className="text-[10px] font-mono tracking-widest text-[#a855f7] uppercase font-bold block mb-2">SCRAMBLED ENTRANCE CODE</span>
            <span className="text-3xl font-extrabold text-white font-mono tracking-widest text-glow-purple flex gap-1.5">
              {scrambledWord.split("").map((c, i) => (
                <span key={i} className="px-2 py-1 bg-white/5 rounded border border-white/10">{c}</span>
              ))}
            </span>
          </div>

          <form onSubmit={handleWordSubmit} className="space-y-6">
            <div className="space-y-4">
              <div>
                <label className="text-[11px] font-mono text-gray-400 block mb-1 uppercase">YOUR ANSWER</label>
                <input
                  type="text"
                  value={cipherInput}
                  onChange={(e) => setCipherInput(e.target.value)}
                  disabled={wordWon !== null}
                  className="w-full p-3 bg-black/50 border border-white/10 rounded-lg text-sm font-mono text-white text-center tracking-widest focus:outline-none focus:border-neon-purple"
                  placeholder="Enter decipher word..."
                />
              </div>

              <div className="flex space-x-2">
                <button
                  type="submit"
                  disabled={wordWon !== null}
                  className={`w-full py-3.5 rounded-xl font-mono font-bold uppercase text-xs tracking-wider transition-all ${
                    wordWon !== null
                      ? "bg-white/5 text-gray-500 border border-white/5 cursor-not-allowed"
                      : "bg-neon-purple glow-purple text-white hover:opacity-95 text-center"
                  }`}
                >
                  DEACTIVATE SYSTEM LOCKS
                </button>
              </div>
            </div>

            {/* Attempts Indicator Bar */}
            <div className="font-mono text-xs space-y-2">
              <div className="flex justify-between text-[11px] text-gray-400">
                <span>Attempts status:</span>
                <span>{wordAttempts} / {maxWordAttempts} attempts used</span>
              </div>
              <div className="flex space-x-1.5">
                {Array.from({ length: maxWordAttempts }).map((_, i) => (
                  <div
                    key={i}
                    className={`h-2.5 flex-1 rounded-full border transition-all ${
                      i < wordAttempts
                        ? "bg-red-500 border-red-500"
                        : "bg-black/40 border-white/5"
                    }`}
                  ></div>
                ))}
              </div>
            </div>

            {/* Feed back panel */}
            <div className={`p-4 rounded-xl border text-center font-mono text-xs ${
              wordWon === true
                ? "bg-green-500/15 border-green-500/25 text-green-400"
                : wordWon === false
                ? "bg-neon-pink/15 border-neon-pink/25 text-neon-pink"
                : "bg-black/35 border-white/5 text-neon-cyan mt-4"
            }`}>
              {wordFeedback}
            </div>

            {wordWon !== null && (
              <div className="flex justify-center space-x-3 mt-6">
                <button
                  type="button"
                  onClick={() => resetWordGame(activeCipherIdx + 1)}
                  className="px-5 py-3 bg-neon-cyan text-slate-950 text-xs font-mono font-bold uppercase tracking-wide rounded-xl flex items-center space-x-1.5"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>Next word cypher &rarr;</span>
                </button>
              </div>
            )}
          </form>
        </div>
      )}

      {/* SLA Guessing Tiers Hints (Right) */}
      <div className="col-span-1 lg:col-span-4 space-y-6">
        <div className="glass-panel p-6 border border-white/5 bg-slate-900/40">
          <h3 className="font-bold text-sm uppercase text-gray-300 tracking-wider mb-4 font-mono flex items-center gap-1.5">
            <Trophy className="w-4 h-4 text-[#fbbf24]" /> MULTIPLIER CODES
          </h3>

          <div className="space-y-3 font-mono text-xs">
            {activeMode === "number" ? (
              <div className="p-3 bg-black/45 rounded-xl border border-white/5 leading-relaxed text-gray-400 text-[11px] space-y-2">
                <span className="font-bold text-white text-xs block mb-1">Tips on Matrix guess:</span>
                <p>&bull; The secret node is generated on-demand between 1 and 25.</p>
                <p>&bull; Submitting directly without calibrating will degrade your reward ratio.</p>
              </div>
            ) : (
              <div className="p-3 bg-black/45 rounded-xl border border-white/5 leading-relaxed text-[#a855f7] text-[11px] space-y-2">
                <span className="font-bold text-white text-xs block mb-1">Active Cypher Clues:</span>
                <p className="border-l-2 border-neon-cyan pl-2 text-white italic">
                  &quot;{wordsPool[activeCipherIdx].hint}&quot;
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
