import React from "react";
import {
  Home,
  Award,
  Disc,
  Wallet,
  Trophy,
  User,
  Gamepad2,
  CheckSquare,
  CreditCard,
  ShieldAlert,
  Bell,
  Terminal,
  Menu,
  X
} from "lucide-react";

interface NavbarProps {
  currentRoute: string;
  onRouteChange: (route: string) => void;
  notificationCount: number;
}

export default function Navbar({ currentRoute, onRouteChange, notificationCount }: NavbarProps) {
  const [drawerOpen, setDrawerOpen] = React.useState(false);

  const primaryNavItems = [
    { id: "dashboard", label: "Home", icon: Home },
    { id: "quiz", label: "Quiz", icon: Award },
    { id: "spin", label: "Spin", icon: Disc },
    { id: "wallet", label: "Wallet", icon: Wallet },
    { id: "leaderboard", label: "Ranks", icon: Trophy }
  ];

  const secondaryNavItems = [
    { id: "auth", label: "Auth Portal", path: "/ui/auth/", icon: User },
    { id: "guess", label: "Guess & Win", path: "/ui/guess/", icon: Gamepad2 },
    { id: "tasks", label: "Task Board", path: "/ui/tasks/", icon: CheckSquare },
    { id: "payouts", label: "Payout Center", path: "/ui/payouts/", icon: CreditCard },
    { id: "fraud", label: "Anti-Cheat", path: "/ui/fraud/", icon: ShieldAlert },
    { id: "notifications", label: "Inbox", path: "/ui/notifications/", icon: Bell, badge: notificationCount }
  ];

  const handleItemClick = (id: string) => {
    onRouteChange(id);
    setDrawerOpen(false);
  };

  return (
    <>
      {/* Desktop Header & Branding */}
      <header className="sticky top-0 z-40 w-full bg-slate-950/85 backdrop-blur-md border-b border-white/5 py-3 px-4 md:px-8 flex justify-between items-center">
        {/* Logo and Brand */}
        <div className="flex items-center space-x-3 cursor-pointer" onClick={() => handleItemClick("dashboard")}>
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-neon-purple to-neon-blue p-[2px] shadow-lg glow-purple flex justify-center items-center">
            <span className="text-white font-extrabold text-sm font-mono tracking-tighter">RV</span>
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight bg-gradient-to-r from-white via-neon-purple to-neon-cyan bg-clip-text text-transparent font-sans">
              RewardVerse
            </h1>
            <p className="text-[10px] text-gray-400 -mt-1 font-mono tracking-wider hidden sm:block">
              GAMIFIED SYSTEM &bull; v1.0.4
            </p>
          </div>
        </div>

        {/* Desktop Primary Nav Rows */}
        <nav className="hidden md:flex items-center space-x-1">
          {primaryNavItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentRoute === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleItemClick(item.id)}
                className={`relative px-4 py-2 rounded-xl text-sm font-medium tracking-wide transition-all duration-300 flex items-center space-x-2 ${
                  isActive
                    ? "bg-neon-purple/20 border border-neon-purple text-neon-purple glow-purple font-semibold"
                    : "text-gray-400 hover:text-white hover:bg-white/5 border border-transparent"
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? "text-neon-purple" : "text-gray-400"}`} />
                <span>{item.label}</span>
                {isActive && (
                  <span className="absolute bottom-1 left-1/2 transform -translate-x-1/2 w-4 h-[2px] bg-neon-purple rounded-full"></span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Actions Menu Right */}
        <div className="flex items-center space-x-2">
          {/* Notifications Shortcut */}
          <button
            onClick={() => handleItemClick("notifications")}
            className="relative p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 text-gray-300 hover:text-white transition-all pointer-events-auto"
          >
            <Bell className="w-5 h-5" />
            {notificationCount > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 bg-neon-pink text-white rounded-full text-[9px] font-bold flex justify-center items-center">
                {notificationCount}
              </span>
            )}
          </button>

          {/* Quick Menu Drawer Trigger for All views */}
          <button
            onClick={() => setDrawerOpen(!drawerOpen)}
            className="p-2 rounded-xl bg-gradient-to-r from-neon-purple/20 to-neon-blue/20 hover:from-neon-purple/30 hover:to-neon-blue/30 border border-white/10 text-white transition-all flex items-center space-x-1"
          >
            <Menu className="w-5 h-5" />
            <span className="text-xs font-mono uppercase font-semibold hidden sm:inline-block">DOCK</span>
          </button>
        </div>
      </header>

      {/* Slideout Utility Dock Drawer */}
      {drawerOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm transition-all flex justify-end">
          <div className="w-full max-w-sm bg-slate-950 border-l border-white/10 h-full p-6 flex flex-col justify-between shadow-2xl overflow-y-auto">
            {/* Header in Drawer */}
            <div>
              <div className="flex justify-between items-center pb-4 border-b border-white/10 mb-6">
                <div>
                  <h3 className="font-bold text-base text-white font-mono tracking-tight flex items-center gap-1.5">
                    <span className="text-neon-cyan">[VIRTUAL]</span> REWARDS SYSTEM
                  </h3>
                  <p className="text-[10px] text-gray-400">Jump quickly into any platform suite</p>
                </div>
                <button
                  onClick={() => setDrawerOpen(false)}
                  className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Drawer Navigation List */}
              <div className="space-y-6">
                {/* Core Modules Group */}
                <div>
                  <span className="text-[10px] font-mono tracking-widest text-[#a855f7] uppercase font-bold block mb-3">
                    Core Dashboard Pages
                  </span>
                  <div className="grid grid-cols-2 gap-2">
                    {primaryNavItems.map((item) => {
                      const Icon = item.icon;
                      const isActive = currentRoute === item.id;
                      return (
                        <button
                          key={item.id}
                          onClick={() => handleItemClick(item.id)}
                          className={`p-3 rounded-xl border text-left transition-all flex flex-col items-start gap-1 ${
                            isActive
                              ? "bg-neon-purple/20 border-neon-purple text-white shadow-lg shadow-purple-500/10"
                              : "bg-white/5 hover:bg-white/10 border-white/5 text-gray-300"
                          }`}
                        >
                          <Icon className={`w-5 h-5 ${isActive ? "text-neon-purple" : "text-neon-cyan"}`} />
                          <span className="text-xs font-semibold">{item.label}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* All Routes / Django Links */}
                <div>
                  <span className="text-[10px] font-mono tracking-widest text-neon-cyan uppercase font-bold block mb-3">
                    Django System URL Mapping
                  </span>
                  <div className="space-y-1.5">
                    {secondaryNavItems.map((item) => {
                      const Icon = item.icon;
                      const isActive = currentRoute === item.id;
                      return (
                        <button
                          key={item.id}
                          onClick={() => handleItemClick(item.id)}
                          className={`w-full p-2.5 rounded-xl border text-left flex items-center justify-between transition-all ${
                            isActive
                              ? "bg-neon-cyan/15 border-neon-cyan text-white"
                              : "bg-white/5 hover:bg-white/10 border-white/5 text-gray-300"
                          }`}
                        >
                          <div className="flex items-center space-x-3">
                            <Icon className={`w-4 h-4 ${isActive ? "text-neon-cyan" : "text-gray-400"}`} />
                            <div className="text-left">
                              <span className="text-xs font-semibold block">{item.label}</span>
                              <span className="text-[9px] text-gray-400 font-mono">{item.path}</span>
                            </div>
                          </div>
                          {item.badge !== undefined && item.badge > 0 && (
                            <span className="bg-neon-pink text-white px-2 py-0.5 text-[9px] rounded-full font-bold">
                              {item.badge} New
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Django Dev Tool Hook in Drawer */}
            <div className="mt-8 border-t border-white/15 pt-5">
              <button
                onClick={() => handleItemClick("django_tool")}
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#ab52f3] to-[#ef4444] hover:opacity-90 border border-purple-500/40 text-xs font-mono font-bold uppercase tracking-wider text-white flex items-center justify-center space-x-2 shadow-lg"
              >
                <Terminal className="w-4 h-4" />
                <span>Django Code Pipeline</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Mobile Sticky Footer Menu */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/90 border-t border-white/10 px-2 py-2 flex justify-around items-center md:hidden backdrop-blur-lg">
        {primaryNavItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentRoute === item.id;
          return (
            <button
              key={item.id}
              onClick={() => handleItemClick(item.id)}
              className={`p-1 flex flex-col items-center justify-center min-w-[55px] transition-all rounded-xl ${
                isActive ? "text-neon-purple shadow-sm bg-purple-500/10" : "text-gray-400"
              }`}
            >
              <Icon className={`w-5 h-5 ${isActive ? "stroke-[2.5px] scale-110" : ""}`} />
              <span className="text-[9px] font-medium mt-1 uppercase tracking-wider">{item.label}</span>
            </button>
          );
        })}

        {/* Floating Dock Menu Button for Mobile navigation */}
        <button
          onClick={() => setDrawerOpen(true)}
          className="p-1 flex flex-col items-center justify-center min-w-[55px] text-neon-cyan"
        >
          <Menu className="w-5 h-5" />
          <span className="text-[9px] font-medium mt-1 uppercase tracking-wider">Dock</span>
        </button>
      </nav>
    </>
  );
}
