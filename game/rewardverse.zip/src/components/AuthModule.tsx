import React, { useState } from "react";
import { UserProfile, Badge } from "../types";
import { Shield, Check, Lock, Star, ToggleLeft, LogIn, ChevronRight, RefreshCw, UserCheck, KeySquare } from "lucide-react";

interface AuthModuleProps {
  user: UserProfile;
  onUpdateUser: (newUser: UserProfile) => void;
  onTriggerToast: (msg: string, type: "success" | "info" | "error") => void;
}

const AVAILABLE_AVATARS = [
  "https://images.unsplash.com/photo-1566492031773-4f4e44671857?q=80&w=250&auto=format&fit=crop", // Male gamer
  "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=250&auto=format&fit=crop", // Female gamer
  "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=250&auto=format&fit=crop", // Casual gamer
  "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=250&auto=format&fit=crop", // Pro streamer
  "https://images.unsplash.com/photo-1628157582853-a796fa650a6a?q=80&w=250&auto=format&fit=crop", // Futuristic Bot
  "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?q=80&w=250&auto=format&fit=crop"  // Synth Neon
];

export default function AuthModule({ user, onUpdateUser, onTriggerToast }: AuthModuleProps) {
  const [isLogin, setIsLogin] = useState<boolean>(true);
  const [typedUser, setTypedUser] = useState<string>(user.username);
  const [typedEmail, setTypedEmail] = useState<string>(user.email);
  const [pass, setPass] = useState<string>("••••••••");

  const saveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateUser({
      ...user,
      username: typedUser || "GamerZero",
      email: typedEmail || "gamer@rewardverse.io"
    });
    onTriggerToast("Profile synchronization successful! (Synced with Django DB Simulator)", "success");
  };

  const handleAvatarSelect = (url: string) => {
    onUpdateUser({
      ...user,
      avatar: url
    });
    onTriggerToast("Avatar changed! Live representation uploaded.", "success");
  };

  const handleVerifyRequest = () => {
    onUpdateUser({
      ...user,
      isVerified: true,
      securityScore: 100
    });
    onTriggerToast("Interactive identity verification complete! Token active.", "success");
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 select-none p-1 pb-16">
      {/* Simulation Header Badge */}
      <div className="lg:col-span-12 glass-panel p-4 flex justify-between items-center border border-neon-blue/20">
        <div className="flex items-center space-x-3">
          <KeySquare className="text-neon-cyan w-5 h-5 animate-pulse" />
          <div>
            <span className="text-xs font-mono text-neon-cyan block">DJANGO PLATFORM ROUTE:</span>
            <span className="text-sm font-bold text-white font-mono tracking-wide">/ui/auth/ [Dual Sandbox]</span>
          </div>
        </div>
        <div className="flex items-center space-x-2 text-xs">
          <span className="px-2 py-1 bg-white/5 border border-white/10 rounded font-mono text-gray-300">
            Cookie: sessionid_active
          </span>
          <span className={`h-2.5 w-2.5 rounded-full ${user.isVerified ? "bg-green-400 animate-ping" : "bg-yellow-400"}`}></span>
        </div>
      </div>

      {/* Profile HUD & Identity Sync Card (Left) */}
      <div className="col-span-1 lg:col-span-4 space-y-6">
        <div className="glass-panel p-6 border border-white/5 bg-slate-900/40 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-neon-purple/5 rounded-full blur-2xl"></div>

          <h3 className="font-bold text-base text-white tracking-tight mb-4 flex items-center gap-1.5 font-mono">
            <UserCheck className="w-4 h-4 text-neon-purple" /> HUD PROFILE CARD
          </h3>

          <div className="flex flex-col items-center text-center">
            {/* Live Profile Image and Border */}
            <div className="relative group cursor-pointer mb-3">
              <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-neon-purple via-neon-cyan to-neon-gold p-[3px] shadow-xl glow-purple transition-transform duration-500 hover:rotate-12">
                <img
                  src={user.avatar}
                  alt="Current Avatar"
                  className="w-full h-full object-cover rounded-full"
                  referrerPolicy="no-referrer"
                />
              </div>
              <span className="absolute -bottom-1 -right-1 bg-neon-gold text-slate-950 font-bold px-2 py-0.5 rounded-full text-[10px] font-mono shadow border border-slate-950">
                Lvl {user.level}
              </span>
            </div>

            <h4 className="text-lg font-bold text-white tracking-wide">{user.username}</h4>
            <p className="text-xs text-gray-400 font-mono mt-0.5">{user.email}</p>

            <div className="w-full bg-black/40 border border-white/5 rounded-xl p-3.5 mt-4 space-y-2.5 font-mono text-xs">
              <div className="flex justify-between">
                <span className="text-gray-400">XP Progress:</span>
                <span className="text-neon-cyan font-bold">{user.xp} / {user.xpToNextLevel}</span>
              </div>
              <div className="w-full h-2 bg-slate-950 rounded-full overflow-hidden">
                <div
                  className="bg-gradient-to-r from-neon-purple to-neon-cyan h-full transition-all duration-300"
                  style={{ width: `${(user.xp / user.xpToNextLevel) * 100}%` }}
                ></div>
              </div>

              <div className="flex justify-between pt-2 border-t border-white/5">
                <span className="text-gray-400">Wallet balance:</span>
                <span className="text-green-400 font-bold">${user.walletBalance.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Gold coins:</span>
                <span className="text-neon-gold font-bold">🪙 {user.coins}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Change Username and Credentials */}
        <div className="glass-panel p-6 border border-white/5 bg-slate-900/40">
          <h3 className="font-bold text-sm uppercase text-gray-300 tracking-wider mb-4 font-mono">
            SYNC GATEWAY (DB UPDATE)
          </h3>
          <form onSubmit={saveProfile} className="space-y-3">
            <div>
              <label className="text-[11px] font-mono text-gray-400 block mb-1">USER HANDLE</label>
              <input
                type="text"
                value={typedUser}
                onChange={(e) => setTypedUser(e.target.value)}
                className="w-full p-2.5 bg-black/50 border border-white/10 rounded-lg text-xs font-mono text-neon-cyan focus:outline-none focus:border-neon-cyan"
                placeholder="Alter handle..."
              />
            </div>
            <div>
              <label className="text-[11px] font-mono text-gray-400 block mb-1">EMAIL NODE</label>
              <input
                type="email"
                value={typedEmail}
                onChange={(e) => setTypedEmail(e.target.value)}
                className="w-full p-2.5 bg-black/50 border border-white/10 rounded-lg text-xs font-mono text-white focus:outline-none focus:border-neon-purple"
                placeholder="Alter email..."
              />
            </div>
            <button
              type="submit"
              className="w-full p-2.5 bg-gradient-to-r from-neon-purple to-neon-blue rounded-lg text-xs font-mono font-bold uppercase text-white shadow hover:opacity-90 active:scale-[0.98] transition-all"
            >
              Sync DB Account
            </button>
          </form>
        </div>
      </div>

      {/* Switch Avatars & Verify Section (Center) */}
      <div className="col-span-1 lg:col-span-5 space-y-6">
        <div className="glass-panel p-6 border border-white/5 bg-slate-900/40">
          <h3 className="font-bold text-sm uppercase text-gray-300 tracking-wider mb-3 font-mono">
            CHOOSE DIGITAL AVATAR
          </h3>
          <p className="text-xs text-gray-400 mb-4 leading-relaxed">
            Select standard neon gamer presets. This will update your template image handle instantly.
          </p>

          <div className="grid grid-cols-3 gap-3.5">
            {AVAILABLE_AVATARS.map((url, idx) => (
              <div
                key={idx}
                onClick={() => handleAvatarSelect(url)}
                className={`group relative aspect-square rounded-xl overflow-hidden cursor-pointer border-2 transition-all p-0.5 ${
                  user.avatar === url
                    ? "border-neon-cyan glow-cyan scale-105"
                    : "border-white/5 hover:border-white/25 hover:scale-[1.02]"
                }`}
              >
                <img
                  src={url}
                  alt={`Avatar Preset ${idx}`}
                  className="w-full h-full object-cover rounded-lg group-hover:rotate-3 transition-transform duration-300"
                  referrerPolicy="no-referrer"
                />
                {user.avatar === url && (
                  <div className="absolute top-1 right-1 bg-neon-cyan text-slate-950 p-[3px] rounded-full">
                    <Check className="w-2.5 h-2.5 stroke-[3px]" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Verification Portal (Badges) */}
        <div className="glass-panel p-6 border border-white/5 bg-slate-900/40 relative">
          <h3 className="font-bold text-sm uppercase text-gray-300 tracking-wider mb-3 font-mono">
            IDENTITY ACCREDITATION
          </h3>
          <p className="text-xs text-gray-400 mb-4 leading-relaxed">
            Validate device fingerprints, browser proxies, and security metrics to earn the legendary Verified Badge.
          </p>

          <div className="bg-black/35 rounded-xl border border-white/5 p-4 space-y-3.5 font-mono text-xs">
            <div className="flex justify-between items-center">
              <span>Verified Status:</span>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${user.isVerified ? "bg-green-500/20 text-green-400 border border-green-500/30" : "bg-yellow-500/20 text-yellow-500 border border-yellow-500/30"}`}>
                {user.isVerified ? "APPROVED" : "UNVERIFIED"}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span>Security Score:</span>
              <span className={`font-bold ${user.securityScore >= 90 ? "text-green-400" : "text-yellow-400"}`}>
                {user.securityScore} / 100
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span>Sandbox Checks:</span>
              <span className="text-neon-cyan font-bold">DEVICE_OK &bull; IP_LOCAL</span>
            </div>
          </div>

          <button
            onClick={handleVerifyRequest}
            disabled={user.isVerified}
            className={`w-full mt-4 p-3 rounded-lg text-xs font-mono font-bold uppercase tracking-wider flex justify-center items-center gap-1.5 transition-all ${
              user.isVerified
                ? "bg-green-500/10 text-green-400 border border-green-500/20 cursor-not-allowed"
                : "bg-neon-cyan shadow glow-cyan text-slate-950 hover:bg-neon-cyan/95 active:scale-[0.98]"
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>{user.isVerified ? "ACCRA CREDIT VALIDATED" : "RUN IDENTITY ACCREDITATION"}</span>
          </button>
        </div>
      </div>

      {/* Django Template Code Panel (Right) */}
      <div className="col-span-1 lg:col-span-3 space-y-6">
        <div className="glass-panel p-5 border border-[#a855f7]/30 bg-[#a855f7]/5 relative">
          <h3 className="font-bold text-xs uppercase text-neon-purple tracking-widest mb-3 font-mono flex items-center gap-1">
            <Shield className="w-3.5 h-3.5" /> PYTHON SECURITY GUARD
          </h3>
          <p className="text-[11px] text-gray-300 leading-relaxed mb-4">
            Protect rewards endpoints from exploit scripts. Use Python's built-in session auth controllers:
          </p>

          <pre className="p-3 bg-black/60 rounded-xl border border-white/5 text-[10px] text-purple-400 font-mono overflow-x-auto">
{`# views.py
from django.contrib.auth.decorators \\
    import login_required

@login_required
def claim_rewards(request):
    user_profile = request.user.profile
    # Block emulator scripts
    if "Postman" in request.META['HTTP_USER_AGENT']:
         return JsonResponse({"error": "No Bypass"}, status=403)
    user_profile.coins += 10
    user_profile.save()`}
          </pre>

          <div className="mt-4 pt-3.5 border-t border-white/5 flex items-center justify-between text-[10px] text-gray-400 font-mono">
            <span>🛡️ csrf_token required</span>
            <span className="text-neon-cyan hover:underline cursor-pointer">View views.py &rarr;</span>
          </div>
        </div>
      </div>
    </div>
  );
}
