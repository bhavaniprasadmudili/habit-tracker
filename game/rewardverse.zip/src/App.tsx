import React, { useState, useEffect } from "react";
import { UserProfile, Task, AppNotification, WalletTransaction, SpinHistory } from "./types";
import Navbar from "./components/Navbar";
import AuthModule from "./components/AuthModule";
import WalletModule from "./components/WalletModule";
import PayoutsModule from "./components/PayoutsModule";
import QuizModule from "./components/QuizModule";
import GuessModule from "./components/GuessModule";
import SpinModule from "./components/SpinModule";
import TasksModule from "./components/TasksModule";
import LeaderboardModule from "./components/LeaderboardModule";
import NotificationsModule from "./components/NotificationsModule";
import FraudModule from "./components/FraudModule";
import DjangoCodeInspector from "./components/DjangoCodeInspector";
import Confetti from "./components/Confetti";

import {
  Coins,
  DollarSign,
  Award,
  Bell,
  CheckSquare,
  Trophy,
  ShieldAlert,
  Terminal,
  Play,
  Share2,
  TrendingUp,
  Clock,
  ChevronRight,
  Sparkles,
  Info
} from "lucide-react";

export default function App() {
  const [currentRoute, setCurrentRoute] = useState<string>("dashboard");
  const [confettiActive, setConfettiActive] = useState<boolean>(false);
  const [djangoInspectorOpen, setDjangoInspectorOpen] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState("");

  // --- GLOBAL PERSISTED SYSTEMS ---
  const [user, setUser] = useState<UserProfile>({
    username: "GamerZero",
    email: "gamer@rewardverse.io",
    avatar: "https://images.unsplash.com/photo-1628157582853-a796fa650a6a?q=80&w=250&auto=format&fit=crop",
    level: 3,
    xp: 65,
    xpToNextLevel: 100,
    coins: 450,
    walletBalance: 12.5,
    streakCount: 3,
    streakCalendar: { day_1: true, day_2: true, day_3: true },
    badges: [],
    rank: 5,
    securityScore: 82,
    isVerified: false,
    deviceCheckOk: true
  });

  const [tasks, setTasks] = useState<Task[]>([
    {
      id: "tsk_daily_streak",
      title: "Consecutive check-in",
      description: "Log in and activate today's streak catalyst checkpoint.",
      rewardType: "coins",
      rewardValue: 150,
      progress: 3,
      maxProgress: 4,
      isCompleted: false,
      isClaimed: false,
      category: "daily",
      iconName: "Gift"
    },
    {
      id: "tsk_watch_ad",
      title: "Stream Hologram adframe",
      description: "Watch a quick 5-second simulated marketing sponsor clip.",
      rewardType: "coins",
      rewardValue: 200,
      progress: 0,
      maxProgress: 1,
      isCompleted: false,
      isClaimed: false,
      category: "daily",
      iconName: "Tv"
    },
    {
      id: "tsk_complete_quiz",
      title: "Acquire full score in Trivia",
      description: "Play today's daily science or web development quiz set.",
      rewardType: "xp",
      rewardValue: 60,
      progress: 0,
      maxProgress: 1,
      isCompleted: false,
      isClaimed: false,
      category: "challenge",
      iconName: "Award"
    },
    {
      id: "tsk_invite_friend",
      title: "Spread referral credentials",
      description: "Copy your custom referral node connection code.",
      rewardType: "coins",
      rewardValue: 250,
      progress: 0,
      maxProgress: 1,
      isCompleted: false,
      isClaimed: false,
      category: "social",
      iconName: "Share2"
    }
  ]);

  const [notifications, setNotifications] = useState<AppNotification[]>([
    {
      id: "notif_welcome",
      title: "Welcome to RewardVerse Django!",
      description: "Successfully connected session. Security engine has assigned standard click thresholds.",
      timestamp: "Today 09:30",
      read: false,
      type: "streak"
    },
    {
      id: "notif_unverified",
      title: "Verification status: Unverified",
      description: "Complete Accra digital identity checks to bypass payout limits.",
      timestamp: "Today 09:12",
      read: false,
      type: "security"
    },
    {
      id: "notif_bonus",
      title: "Multipliers Weekend Enabled",
      description: "All trivia questions completed this weekend will trigger 1.5x coin bonuses.",
      timestamp: "Yesterday 18:00",
      read: true,
      type: "bonus"
    }
  ]);

  const [transactions, setTransactions] = useState<WalletTransaction[]>([
    {
      id: "TX-902102",
      type: "earn",
      amount: 150,
      currency: "coins",
      description: "Streak Bonus Check-in (Day 3)",
      timestamp: "2026-05-23 09:14:10",
      status: "completed"
    },
    {
      id: "TX-423543",
      type: "earn",
      amount: 100,
      currency: "coins",
      description: "Spin Wheel Reward",
      timestamp: "2026-05-23 08:30:15",
      status: "completed"
    }
  ]);

  const [spinHistory, setSpinHistory] = useState<SpinHistory[]>([]);

  // Toast Notification Simulation
  const [toast, setToast] = useState<{ msg: string; type: "success" | "info" | "error" } | null>(null);

  const triggerToast = (msg: string, type: "success" | "info" | "error") => {
    setToast({ msg, type });
    // Trigger confetti on successful rewards
    if (type === "success" && (msg.includes("+🪙") || msg.includes("+$") || msg.includes("CLAIM"))) {
      setConfettiActive(true);
    }
    setTimeout(() => setToast(null), 3000);
  };

  const handleUpdateUser = (newUser: UserProfile) => {
    // Audit limits: if Level-up condition met
    let tempUser = { ...newUser };
    if (tempUser.xp >= tempUser.xpToNextLevel) {
      tempUser.xp -= tempUser.xpToNextLevel;
      tempUser.level += 1;
      tempUser.xpToNextLevel = tempUser.level * 100;
      triggerToast(`LEVEL UP! You compiled into Level ${tempUser.level}!`, "success");
    }
    setUser(tempUser);
  };

  const handleAddTransaction = (tx: WalletTransaction) => {
    setTransactions((prev) => [tx, ...prev]);
  };

  const handleAddSpinHistory = (historyItem: SpinHistory) => {
    setSpinHistory((prev) => [historyItem, ...prev]);
  };

  // Notification Operations
  const handleMarkRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  const handleClearAllNotifs = () => {
    setNotifications([]);
    triggerToast("Alerts log cleared completely.", "info");
  };

  const handleMarkAllReadNotifs = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    triggerToast("Marked all alerts as read.", "info");
  };

  const unreadNotifCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="min-h-screen bg-[#05020c] text-gray-200 pb-24 md:pb-6 flex flex-col relative font-sans">
      {/* Physics Confetti layer */}
      <Confetti active={confettiActive} onAnimationComplete={() => setConfettiActive(false)} />

      {/* Floating Global Micro Toast notification panel */}
      {toast && (
        <div className="fixed top-20 right-4 z-50 p-4 rounded-xl border-t bg-slate-950/95 shadow-2xl flex items-center space-x-3 text-xs font-mono max-w-sm border-l-4 transition-all animate-bounce"
             style={{
               borderColor: toast.type === "success" ? "#06b6d4" : toast.type === "error" ? "#ec4899" : "#fbbf24"
             }}>
          <span className="text-xl">
            {toast.type === "success" ? "⚡" : toast.type === "error" ? "🚨" : "🔔"}
          </span>
          <div className="leading-tight text-white select-none">
            {toast.msg}
          </div>
        </div>
      )}

      {/* Futuristic Header Navbar */}
      <Navbar
        currentRoute={currentRoute}
        onRouteChange={(route) => {
          setCurrentRoute(route);
          if (route === "django_tool") setDjangoInspectorOpen(true);
        }}
        notificationCount={unreadNotifCount}
      />

      {/* Main Dynamic View Content Container */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 md:px-8 py-6">
        {djangoInspectorOpen ? (
          <div className="animate-fade-in mb-8">
            <DjangoCodeInspector onClose={() => {
              setDjangoInspectorOpen(false);
              setCurrentRoute("dashboard");
            }} />
          </div>
        ) : (
          <>
            {/* Dashboard Homepage Integration */}
            {currentRoute === "dashboard" && (
              <div className="space-y-6">
                {/* 1. TOP STATS CARDS HUD */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  {/* Gamer Profile Header Plate */}
                  <div className="md:col-span-2 glass-panel p-5 border border-white/5 bg-slate-900/40 relative overflow-hidden flex items-center space-x-4">
                    <div className="relative">
                      <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-neon-purple to-neon-cyan p-[2.5px] shadow-lg">
                        <img src={user.avatar} className="w-full h-full object-cover rounded-full" alt="User avatar" />
                      </div>
                      <span className="absolute -bottom-1.5 -right-1.5 bg-[#fbbf24] text-slate-950 font-extrabold text-[9px] px-1.5 py-0.5 rounded-full font-mono">
                        Lvl {user.level}
                      </span>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-white tracking-wide">{user.username}</span>
                        {user.isVerified && (
                          <span className="text-green-400 font-bold text-xs bg-green-500/15 py-0.5 px-1.5 rounded border border-green-500/20 text-[9px] uppercase tracking-wider">Verified</span>
                        )}
                      </div>
                      <p className="text-[10px] text-gray-400 font-mono mt-0.5 mt-1">XP Progression Matcher</p>
                      <div className="w-full bg-black/40 h-2 rounded-full mt-2 overflow-hidden border border-white/5">
                        <div className="bg-gradient-to-r from-neon-purple to-neon-cyan h-full transition-all duration-300"
                             style={{ width: `${(user.xp / user.xpToNextLevel) * 100}%` }}></div>
                      </div>
                    </div>
                  </div>

                  {/* Coin HUD balance card */}
                  <div className="glass-panel p-5 border border-neon-gold/10 bg-slate-900/40 font-mono flex items-center justify-between">
                    <div>
                      <span className="text-[10px] uppercase text-gray-400 tracking-wider">Virtual Vault Balance</span>
                      <h3 className="text-2xl font-extrabold text-white mt-1 text-glow-gold flex items-center gap-1.5">
                        🪙 {user.coins}
                      </h3>
                      <p className="text-[8px] text-gray-400 mt-2">&bull; Convert to dollars in exchange machine</p>
                    </div>
                  </div>

                  {/* Cash USD wallet balance card */}
                  <div className="glass-panel p-5 border border-emerald-500/10 bg-slate-900/40 font-mono flex items-center justify-between">
                    <div>
                      <span className="text-[10px] uppercase text-gray-400 tracking-wider">Liquid Wallet Balance</span>
                      <h3 className="text-2xl font-extrabold text-emerald-300 mt-1 text-glow-cyan">
                        ${user.walletBalance.toFixed(2)}
                      </h3>
                      <p className="text-[8px] text-gray-400 mt-2">&bull; Claim cashout requests at payouts desk</p>
                    </div>
                  </div>
                </div>

                {/* 2. LIVE STREAK SUMMARY WRAPPER */}
                <div className="glass-panel p-5 border border-[#fbbf24]/10 bg-gradient-to-r from-amber-950/10 via-slate-900/20 to-slate-900/20 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h4 className="font-bold text-xs text-white uppercase tracking-wider flex items-center gap-1.5 font-mono">
                      🔥 STREAK LOG CHECKPOINT
                    </h4>
                    <p className="text-xs text-gray-400 mt-1">Claim your sequential logging multipliers instantly below.</p>
                  </div>
                  <button
                    onClick={() => setCurrentRoute("tasks")}
                    className="px-5 py-2.5 bg-gradient-to-r from-neon-gold via-yellow-400 to-amber-500 hover:opacity-95 text-slate-950 font-bold text-xs font-mono rounded-xl transition-all shadow-md flex items-center justify-center space-x-1"
                  >
                    <span>Check-In Streak Board &rarr;</span>
                  </button>
                </div>

                {/* Quick search games bar */}
                <div className="flex items-center space-x-3 bg-slate-900/30 p-1 rounded-2xl border border-white/5 pl-4 max-w-md">
                  <span className="text-xs font-mono text-neon-cyan select-none uppercase font-bold text-[11px]">System Search:</span>
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search game modules..."
                    className="flex-1 bg-transparent border-0 text-white text-xs font-mono focus:ring-0 focus:outline-none placeholder:text-gray-500"
                  />
                </div>

                {/* 3. QUICK PLAYABLE GAMES SECTION */}
                <div>
                  <h3 className="font-bold text-[#a855f7] font-mono tracking-widest text-xs uppercase mb-4 block">
                    Quantum Mini-games console
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {/* Game 1: Daily Quiz */}
                    <div className="glass-panel p-5 border border-neon-purple/20 bg-gradient-to-b from-purple-950/5 to-black/30 hover:border-neon-purple/50 transition-all cursor-pointer group flex flex-col justify-between"
                         onClick={() => setCurrentRoute("quiz")}>
                      <div>
                        <span className="text-[9px] uppercase font-mono text-neon-purple font-extrabold tracking-widest">TRIVIA CATALYST</span>
                        <h4 className="text-base font-bold text-white tracking-wide mt-1 group-hover:text-neon-purple transition-colors">Daily Quiz Quest</h4>
                        <p className="text-xs text-gray-400 mt-1">Take 5 development trivia challenges, prove score ratios and earn gold coins.</p>
                      </div>
                      <div className="flex justify-between items-center mt-6 font-mono text-[10px]">
                        <span className="text-[#a855f7] font-bold">🪙 Up to +280</span>
                        <span className="text-white bg-white/5 px-2 py-0.5 rounded border border-white/5 uppercase font-semibold">Play Quiz &rarr;</span>
                      </div>
                    </div>

                    {/* Game 2: Spin Wheel */}
                    <div className="glass-panel p-5 border border-neon-pink/20 bg-gradient-to-b from-pink-950/5 to-black/30 hover:border-neon-pink/50 transition-all cursor-pointer group flex flex-col justify-between"
                         onClick={() => setCurrentRoute("spin")}>
                      <div>
                        <span className="text-[9px] uppercase font-mono text-neon-pink font-extrabold tracking-widest">JACKPOT MULTIPLIER</span>
                        <h4 className="text-base font-bold text-white tracking-wide mt-1 group-hover:text-neon-pink transition-colors">Quantum Spin Wheel</h4>
                        <p className="text-xs text-gray-400 mt-1">Spin the high-resolution vector wheel for Coins, XP multipliers or cash mystery boxes.</p>
                      </div>
                      <div className="flex justify-between items-center mt-6 font-mono text-[10px]">
                        <span className="text-neon-pink font-bold">5 Spins Daily</span>
                        <span className="text-white bg-white/5 px-2 py-0.5 rounded border border-white/5 uppercase font-semibold">Launch Spin &rarr;</span>
                      </div>
                    </div>

                    {/* Game 3: Guess Cipher */}
                    <div className="glass-panel p-5 border border-neon-cyan/20 bg-gradient-to-b from-cyan-950/5 to-black/30 hover:border-neon-cyan/50 transition-all cursor-pointer group flex flex-col justify-between"
                         onClick={() => setCurrentRoute("guess")}>
                      <div>
                        <span className="text-[9px] uppercase font-mono text-neon-cyan font-extrabold tracking-widest">CYPHER SOLVER</span>
                        <h4 className="text-base font-bold text-white tracking-wide mt-1 group-hover:text-neon-cyan transition-colors">Guess & Win Cipher</h4>
                        <p className="text-xs text-gray-400 mt-1">Guess core coefficient matrix numbers or unscramble Python compiler terms.</p>
                      </div>
                      <div className="flex justify-between items-center mt-6 font-mono text-[10px]">
                        <span className="text-neon-cyan font-bold">Multiplier 5.0x</span>
                        <span className="text-white bg-white/5 px-2 py-0.5 rounded border border-white/5 uppercase font-semibold">Unscramble &rarr;</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* 4. ACTIVE TASKS & LEADERBOARD ROWS PREVIEW */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  {/* Task checklist */}
                  <div className="lg:col-span-8 space-y-4">
                    <h3 className="font-bold text-[#06b6d4] font-mono tracking-widest text-xs uppercase mb-1 block">
                      Active Campaign Quests
                    </h3>
                    <div className="space-y-3">
                      {tasks.slice(0, 3).map((task) => (
                        <div key={task.id} className="p-4 glass-panel border border-white/5 bg-slate-900/30 flex justify-between items-center font-mono">
                          <div className="space-y-1">
                            <span className="font-bold text-xs text-white block">{task.title}</span>
                            <span className="text-[10px] text-gray-400 block">{task.description}</span>
                          </div>
                          <button
                            onClick={() => setCurrentRoute("tasks")}
                            className="px-3.5 py-1.5 bg-white/5 hover:bg-white/10 border border-white/5 rounded-xl text-[10px] text-neon-cyan uppercase font-bold"
                          >
                            Explore Quest &rarr;
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Leaderboard preview stats */}
                  <div className="lg:col-span-4 space-y-4">
                    <h3 className="font-bold text-[#fbbf24] font-mono tracking-widest text-xs uppercase mb-1 block">
                      Podium ranking preview
                    </h3>
                    <div className="glass-panel p-5 border border-white/5 bg-slate-900/40 space-y-3 font-mono text-xs">
                      <div className="flex justify-between items-center pb-2 border-b border-white/5">
                        <span className="font-bold text-white uppercase text-[10px]">Top Challenger</span>
                        <span className="text-neon-gold">🥇 Rank #1</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 rounded-full border border-neon-gold overflow-hidden">
                          <img src="https://images.unsplash.com/photo-1566492031773-4f4e44671857?q=80&w=250&auto=format&fit=crop" alt="Challenger" />
                        </div>
                        <div>
                          <span className="font-bold text-white block">VaporShogun</span>
                          <span className="text-[9px] text-gray-400">Level 42 &bull; 14.2K XP</span>
                        </div>
                      </div>
                      <button
                        onClick={() => setCurrentRoute("leaderboard")}
                        className="w-full mt-4 py-2 bg-[#fbbf24]/10 border border-[#fbbf24]/20 text-[#fbbf24] rounded-lg text-center text-[10px] uppercase font-bold tracking-wider"
                      >
                        View Global Leaderboard &rarr;
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* ROUTE MOUNT CONTROLLER */}
            {currentRoute === "auth" && (
              <AuthModule user={user} onUpdateUser={handleUpdateUser} onTriggerToast={triggerToast} />
            )}
            {currentRoute === "wallet" && (
              <WalletModule
                user={user}
                onUpdateUser={handleUpdateUser}
                transactions={transactions}
                onAddTransaction={handleAddTransaction}
                onTriggerToast={triggerToast}
                onNavigateToPayouts={() => setCurrentRoute("payouts")}
              />
            )}
            {currentRoute === "payouts" && (
              <PayoutsModule
                user={user}
                onUpdateUser={handleUpdateUser}
                onAddTransaction={handleAddTransaction}
                onTriggerToast={triggerToast}
                onNavigateToAuth={() => setCurrentRoute("auth")}
              />
            )}
            {currentRoute === "quiz" && (
              <QuizModule
                user={user}
                onUpdateUser={handleUpdateUser}
                onAddTransaction={handleAddTransaction}
                onTriggerToast={triggerToast}
                onNavigateToDashboard={() => setCurrentRoute("dashboard")}
              />
            )}
            {currentRoute === "guess" && (
              <GuessModule
                user={user}
                onUpdateUser={handleUpdateUser}
                onAddTransaction={handleAddTransaction}
                onTriggerToast={triggerToast}
              />
            )}
            {currentRoute === "spin" && (
              <SpinModule
                user={user}
                spinHistory={spinHistory}
                onUpdateUser={handleUpdateUser}
                onAddTransaction={handleAddTransaction}
                onAddSpinHistory={handleAddSpinHistory}
                onTriggerToast={triggerToast}
              />
            )}
            {currentRoute === "tasks" && (
              <TasksModule
                user={user}
                tasks={tasks}
                onUpdateUser={handleUpdateUser}
                onUpdateTasks={setTasks}
                onAddTransaction={handleAddTransaction}
                onTriggerToast={triggerToast}
              />
            )}
            {currentRoute === "leaderboard" && (
              <LeaderboardModule user={user} />
            )}
            {currentRoute === "notifications" && (
              <NotificationsModule
                notifications={notifications}
                onMarkRead={handleMarkRead}
                onClearAll={handleClearAllNotifs}
                onMarkAllRead={handleMarkAllReadNotifs}
              />
            )}
            {currentRoute === "fraud" && (
              <FraudModule
                user={user}
                onUpdateUser={handleUpdateUser}
                onTriggerToast={triggerToast}
                onAddNotification={(n) => setNotifications((p) => [n, ...p])}
              />
            )}
          </>
        )}
      </main>

      {/* Persistent global footer credits */}
      <footer className="w-full text-center py-6 border-t border-white/5 mt-16 text-[10px] text-gray-500 font-mono tracking-wider">
        <span>🤖 DESIGN COMPATIE FOR DJANGO SYSTEM &bull; NO SYSTEM CLUTTER</span>
      </footer>
    </div>
  );
}
